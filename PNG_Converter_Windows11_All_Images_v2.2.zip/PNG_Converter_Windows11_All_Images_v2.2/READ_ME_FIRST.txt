PNG CONVERTER FOR WINDOWS 11 - VERSION 2.2 (x64)

SETUP: RUN ONE FILE
1. Extract the entire ZIP.
2. Double-click INSTALL.cmd.
3. Choose Yes in the Windows administrator prompt and wait for "2.2 is ready".

INSTALL.cmd completes the program installation, right-click registration,
desktop shortcut and required Windows folder permission together.
There is no second permission script to run. Folder protection stays enabled.
Run INSTALL.cmd again if installation was cancelled or did not finish.

The installed application lives in Program Files. Moving or deleting the extracted
ZIP folder afterwards does not break the converter. Reinstalling uses the same
application location and reuses the registered converter shortcut.

CONVERT IMAGES
Select your images, right-click > Show more options >
Convert to PNG (replace originals).
Or drag the selection onto Convert to PNG (batch) on the desktop.
Double-click the shortcut for a multiple-file picker.
You can select 100+ files; no image paths need to be typed or pasted.

WHAT VERSION 2.2 FIXES
The right-click command has its own native Windows selection handler. It starts
the converter directly and does not depend on a background helper, copy flags or
a long command line. The same native adapter handles the desktop shortcut's drops.
Windows receives only a short selection-request name; all selected image paths
are copied into that request before conversion starts. The request is consumed
once and removed. Setup installs the application and adapters in Program Files.

IMAGE FORMATS
The converter attempts to decode image content without a JPEG-only filename filter.
The bundled readers include JPEG/JFIF, BMP, TIFF, GIF, WebP, AVIF, HEIC/HEIF,
JPEG XL, JPEG 2000, TGA, ICO, SVG/SVGZ, PSD and other supported image formats.
No separate ImageMagick installation is needed. Images are processed locally.
Files already named .png are left as they are. Folders are skipped.
Non-images, damaged images and formats requiring unavailable external tools are
left unchanged with an explanation in the progress window and log.

Each output is saved beside its source. Existing PNGs are never overwritten;
collisions use names such as photo (converted 1).png.
The converter finishes writing, flushes, verifies PNG checksums/structure and
reopens/checks the final image before deleting that source.
Write, verification, logging or deletion errors retain the original.

A single PNG cannot hold an animation, multiple pages or editable layers.
For those sources the converter makes a PNG preview and keeps the complete original.
Precision above what PNG can preserve is retained. Other editing/camera metadata
is not guaranteed to survive conversion.

PROGRESS AND LOGS
The result window shows each file, errors and the final summary, and stays open.
Stop after this file finishes that image safely and leaves the rest unchanged.
Open log folder shows the CSV log and text summary.
Logs: %LOCALAPPDATA%\PNGConverterBatchV2\Logs

OneDrive files may take time to download. Download/read failures keep the source.
Deleting a successfully verified source in a synced folder syncs that deletion.
Spaces, Unicode names and large selections are transferred as Windows file data
and a complete selection request, rather than as a long command-line list.

UNINSTALL
UNINSTALL.cmd removes this user's converter menu, startup entry and current shortcut.
Completed PNGs, logs and application files are retained. Windows machine startup
class registrations and the converter-specific folder permission remain associated
with the installed application. Other applications and their permissions are kept.

VERIFICATION AND SOURCE
See VERIFICATION.txt for actual right-click tests and remaining testing limits.
The src folder is for rebuilding/testing the software; normal users run INSTALL.cmd.
The bundled ImageMagick 7.1.2-32 Q16 x64 comes from the official ImageMagick archive.
Its executable signature was verified as ImageMagick Studio LLC.
Its license and third-party notices are included in engine.
