@echo off
setlocal
"%~dp0PNGConverterBatch.exe" --install
if errorlevel 1 (
  echo.
  echo Installation did not finish. Read the error window above.
  pause
  exit /b 1
)
exit /b 0
