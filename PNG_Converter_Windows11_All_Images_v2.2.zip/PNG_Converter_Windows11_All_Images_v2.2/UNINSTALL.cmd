@echo off
setlocal
"%~dp0PNGConverterBatch.exe" --uninstall
if errorlevel 1 (
  echo.
  echo Uninstall did not finish. Read the error window above.
  pause
  exit /b 1
)
exit /b 0
