using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;
using ComDataObject = System.Runtime.InteropServices.ComTypes.IDataObject;

namespace PNGConverterBatch
{
    internal static class Tests
    {
        private static string root;
        private static int passed, failed;
        private static string filter;
        private static readonly List<string> report = new List<string>();
        private static readonly Guid TestClsid = new Guid("28B04ABC-667A-4E62-A7C4-D4BBE0852285");
        [DllImport("ole32.dll")] private static extern int CoCreateInstance(ref Guid clsid, IntPtr outer, uint context, ref Guid iid, [MarshalAs(UnmanagedType.Interface)] out object result);
        private static void Assert(bool value, string message) { if (!value) throw new Exception(message); }
        private static void Check(string name, Action test)
        {
            if (filter != null && name.IndexOf(filter, StringComparison.OrdinalIgnoreCase) < 0) return;
            Converter.ResetHooks();
            try { test(); passed++; report.Add("PASS " + name); Console.WriteLine("PASS " + name); }
            catch (Exception error) { failed++; report.Add("FAIL " + name + ": " + error); Console.WriteLine("FAIL " + name + ": " + error.Message); }
            finally { Converter.ResetHooks(); }
        }
        private static string ImageFile(string name, int width = 31, int height = 19)
        {
            string path = Path.Combine(root, name); Directory.CreateDirectory(Native.LongPath(Path.GetDirectoryName(path)));
            using (Bitmap image = new Bitmap(width, height))
            {
                for (int y = 0; y < height; y++) for (int x = 0; x < width; x++) image.SetPixel(x, y, Color.FromArgb((x * 47 + y * 11) & 255, (x * 13 + y * 43) & 255, (x * 5 + y * 37) & 255));
                using (FileStream output = new FileStream(Native.LongPath(path), FileMode.CreateNew, FileAccess.Write)) image.Save(output, ImageFormat.Jpeg);
            }
            return path;
        }
        private static string FileHash(string path) { using (FileStream file = File.OpenRead(Native.LongPath(path))) return Converter.Hash(file); }
        private static string DecodedHash(string path)
        { using (FileStream file = File.OpenRead(Native.LongPath(path))) using (Bitmap image = (Bitmap)Image.FromStream(file, false, true)) return Converter.Pixels(image); }
        private static Result Convert(string path)
        {
            using (DurableLog log = new DurableLog(Path.Combine(root, "log-" + Guid.NewGuid().ToString("N") + ".csv"))) return Converter.ConvertOne(path, log, stage => { });
        }
        private static void ReplaceOK(Result result, string pixels)
        {
            Assert(result.Status == "REPLACED", result.Status + ": " + result.Detail);
            Assert(!File.Exists(Native.LongPath(result.Source)), "Original still exists.");
            Assert(File.Exists(Native.LongPath(result.Output)), "PNG missing.");
            Assert(DecodedHash(result.Output) == pixels, "Independent pixel comparison failed.");
        }
        private static DataObject Data(string[] paths) { DataObject data = new DataObject(); StringCollection list = new StringCollection(); list.AddRange(paths); data.SetFileDropList(list); return data; }
        private static void InjectApp(string path, byte marker, byte[] body)
        {
            byte[] jpeg = File.ReadAllBytes(Native.LongPath(path));
            using (MemoryStream output = new MemoryStream())
            {
                output.Write(jpeg, 0, 2); output.WriteByte(255); output.WriteByte(marker); int size = body.Length + 2; output.WriteByte((byte)(size >> 8)); output.WriteByte((byte)size);
                output.Write(body, 0, body.Length); output.Write(jpeg, 2, jpeg.Length - 2); File.WriteAllBytes(Native.LongPath(path), output.ToArray());
            }
        }
        private static void ExifOrientation(string path, byte orientation)
        {
            // Little endian EXIF IFD0 with one SHORT orientation entry.
            byte[] exif = { 69,120,105,102,0,0,73,73,42,0,8,0,0,0,1,0,18,1,3,0,1,0,0,0,orientation,0,0,0,0,0,0,0 };
            InjectApp(path, 225, exif);
        }
        private static string[] LargeSelection()
        { return Enumerable.Range(0, 1200).Select(i => Path.Combine(root, "OneDrive - Test company", new string('d', 180), "image [" + i + "] space & $ ! % ' - 漢字.jpeg")).ToArray(); }
        private static int Server(string reportPath, Guid serverId)
        {
            Native.Check(Native.OleInitialize(IntPtr.Zero)); uint cookie = 0; DropFactory factory = new DropFactory();
            try
            {
                ShellDropTarget.Submit = paths => File.WriteAllLines(reportPath, paths, new UTF8Encoding(true));
                ShellDropTarget.ReportError = error => File.WriteAllText(reportPath + ".error", error.ToString());
                Guid clsid = serverId; Native.Check(Native.CoRegisterClassObject(ref clsid, factory, 4, 5, out cookie)); Native.Check(Native.CoResumeClassObjects());
                File.WriteAllText(reportPath + ".ready", "ready");
                System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer { Interval = 200 };
                DateTime started = DateTime.UtcNow;
                timer.Tick += delegate { if (File.Exists(reportPath + ".quit") || (DateTime.UtcNow - started).TotalSeconds > 90) Application.ExitThread(); };
                timer.Start(); Application.Run(); timer.Dispose(); return 0;
            }
            finally { if (cookie != 0) Native.CoRevokeClassObject(cookie); GC.KeepAlive(factory); Native.OleUninitialize(); }
        }
        private static void WaitFor(string file, Process child)
        {
            Stopwatch watch = Stopwatch.StartNew();
            while (!File.Exists(file))
            {
                if (child.HasExited) throw new Exception("COM test server exited with " + child.ExitCode);
                if (watch.Elapsed.TotalSeconds > 45) throw new TimeoutException("COM test server timed out.");
                Thread.Sleep(100);
            }
        }
        [STAThread] private static int Main(string[] args)
        {
            if (args.Length >= 2 && args[0] == "--com-server") { Guid serverId = TestClsid, supplied; if (args.Length >= 3 && Guid.TryParse(args[2], out supplied)) serverId = supplied; return Server(args[1], serverId); }
            if (args.Length >= 3) filter = args[2];
            root = args.Length > 0 ? Path.GetFullPath(args[0]) : Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "test-scratch-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(root); Console.WriteLine("Disposable test files: " + root);
            ImageEngine.ScratchOverride = Path.Combine(root, "decoder scratch");
            Native.Check(Native.OleInitialize(IntPtr.Zero));
            try
            {
                Check("single JPEG: exact decoded pixels and verified replacement", delegate { string path = ImageFile("single.jpg"); string pixels = DecodedHash(path); ReplaceOK(Convert(path), pixels); });
                Check("150 real images, >32K path list, mixed JPG/JPEG and spaces", delegate
                {
                    string folder = "OneDrive - Test company\\" + new string('p', 100) + "\\" + new string('q', 75);
                    List<string> paths = new List<string>(); Dictionary<string, string> pixels = new Dictionary<string, string>();
                    for (int i = 0; i < 150; i++) { string path = ImageFile(Path.Combine(folder, "batch image [" + i.ToString("D3") + "] ' & ! % 漢字." + (i % 2 == 0 ? "JPG" : "jpeg"))); paths.Add(path); pixels[path] = DecodedHash(path); }
                    Assert(paths.Sum(p => p.Length + 3) > 32767, "Fixture didn't exceed command-line length.");
                    List<string> received = ShellSelection.Read((ComDataObject)Data(paths.ToArray())); Assert(received.SequenceEqual(paths), "Selected filenames changed or were truncated.");
                    BatchSummary batch = Converter.Run(received, Path.Combine(root, "batch logs"), n => { }, () => false);
                    Assert(batch.Replaced == 150 && batch.Failed == 0 && batch.Kept == 0, batch.Text);
                    foreach (Result result in batch.Results) ReplaceOK(result, pixels[result.Source]);
                    Assert(File.Exists(batch.LogPath) && File.Exists(batch.SummaryPath), "Log or summary missing.");
                    Assert(File.ReadAllLines(batch.LogPath).Length == 301, "Missing durable verification/results records.");
                });
                Check("existing PNGs and numbered collisions remain byte-identical", delegate
                {
                    string source = ImageFile("collision.jpg"), existing = Path.ChangeExtension(source, ".png");
                    File.WriteAllText(existing, "existing user file"); File.WriteAllText(Path.Combine(root, "collision (converted 1).png"), "second existing file");
                    string a = FileHash(existing), b = FileHash(Path.Combine(root, "collision (converted 1).png")); Result result = Convert(source);
                    Assert(result.Status == "REPLACED" && result.Output.EndsWith(" (converted 2).png"), result.Detail);
                    Assert(FileHash(existing) == a && FileHash(Path.Combine(root, "collision (converted 1).png")) == b, "Existing PNG changed.");
                });
                Check("JPG and JPEG with the same stem both survive as distinct PNGs", delegate
                {
                    string a = ImageFile("same.jpg"), b = ImageFile("same.jpeg", 23, 17); string pa = DecodedHash(a), pb = DecodedHash(b);
                    Result ra = Convert(a), rb = Convert(b); ReplaceOK(ra, pa); ReplaceOK(rb, pb); Assert(ra.Output != rb.Output, "Outputs clobbered each other.");
                });
                Check("filename created during publication is never overwritten", delegate
                {
                    string source = ImageFile("race.jpg"), png = Path.ChangeExtension(source, ".png");
                    Converter.BeforePublish = p => File.WriteAllText(png, "race winner"); Result result = Convert(source);
                    Assert(result.Status == "REPLACED" && result.Output != png && File.ReadAllText(png) == "race winner", "Race overwrote an existing file.");
                });
                Check("255-character filename collision is converted without clobbering", delegate
                {
                    string source = ImageFile(new string('f', 251) + ".jpg"), existing = Path.ChangeExtension(source, ".png");
                    File.WriteAllText(Native.LongPath(existing), "existing longest filename"); string pixels = DecodedHash(source), hash = FileHash(existing); Result result = Convert(source);
                    ReplaceOK(result, pixels); Assert(Path.GetFileName(result.Output).Length <= 255 && FileHash(existing) == hash, "Long filename collision lost existing PNG.");
                });
                Check("corrupt JPEG is preserved byte-for-byte", delegate { string path = Path.Combine(root, "corrupt.jpg"); File.WriteAllText(path, "not an image"); string hash = FileHash(path); Result result = Convert(path); Assert(result.Status == "FAILED" && FileHash(path) == hash, "Corrupt input was changed."); });
                Check("truncated JPEG is rejected even when a decoder could accept it", delegate { string path = ImageFile("truncated.jpg"); byte[] bytes = File.ReadAllBytes(path); File.WriteAllBytes(path, bytes.Take(bytes.Length - 2).ToArray()); string hash = FileHash(path); Result result = Convert(path); Assert(result.Status == "FAILED" && FileHash(path) == hash && !File.Exists(Path.ChangeExtension(path, ".png")), result.Detail); });
                Check("image content is decoded despite a different filename extension", delegate { string path = Path.Combine(root, "disguised.jpg"); using (Bitmap bitmap = new Bitmap(7, 8)) bitmap.Save(path, ImageFormat.Png); string pixels = DecodedHash(path); ReplaceOK(Convert(path), pixels); });
                Check("locked source fails safely", delegate { string path = ImageFile("locked.jpg"); string hash = FileHash(path); using (FileStream locked = new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) Assert(Convert(path).Status == "FAILED", "Locked file wasn't rejected."); Assert(FileHash(path) == hash && !File.Exists(Path.ChangeExtension(path, ".png")), "Locked original changed."); });
                Check("read-only source yields verified PNG while retaining original", delegate
                { string path = ImageFile("readonly.jpg"); string hash = FileHash(path); File.SetAttributes(path, FileAttributes.ReadOnly); try { Result result = Convert(path); Assert(result.Status == "PNG_CREATED_ORIGINAL_KEPT" && FileHash(path) == hash && File.Exists(result.Output), result.Status + ": " + result.Detail); } finally { File.SetAttributes(path, FileAttributes.Normal); } });
                Check("source and final PNG are protected from edits during deletion", delegate
                {
                    string path = ImageFile("protected.jpg"); bool sourceBlocked = false, outputBlocked = false;
                    Converter.BeforeDelete = p =>
                    {
                        try { using (FileStream file = new FileStream(p, FileMode.Open, FileAccess.Write)) { } } catch (IOException) { sourceBlocked = true; }
                        try { using (FileStream file = new FileStream(Path.ChangeExtension(p, ".png"), FileMode.Open, FileAccess.Write)) { } } catch (IOException) { outputBlocked = true; }
                    };
                    Assert(Convert(path).Status == "REPLACED" && sourceBlocked && outputBlocked, "A source or destination could change before deletion.");
                });
                Check("simulated write failure leaves original unchanged", delegate { string path = ImageFile("write-fail.jpg"); string hash = FileHash(path); Converter.BeforeWrite = p => { throw new IOException("Simulated disk write error"); }; Assert(Convert(path).Status == "FAILED" && FileHash(path) == hash && !File.Exists(Path.ChangeExtension(path, ".png")), "Write failure lost source."); });
                Check("temporary PNG corruption blocks deletion", delegate { string path = ImageFile("temp-corrupt.jpg"); string hash = FileHash(path); Converter.BeforeTempVerify = p => File.WriteAllText(p, "bad png"); Assert(Convert(path).Status == "FAILED" && FileHash(path) == hash && !File.Exists(Path.ChangeExtension(path, ".png")), "Bad temporary output permitted deletion."); });
                Check("publication failure blocks deletion and cleans own temporary file", delegate { string path = ImageFile("publish-fail.jpg"); string hash = FileHash(path); Converter.BeforePublish = p => { throw new IOException("Simulated publication failure"); }; Assert(Convert(path).Status == "FAILED" && FileHash(path) == hash, "Publish failure lost source."); Assert(!Directory.GetFiles(root, ".png-converter-*.tmp").Any(), "Temporary file leaked."); });
                Check("final PNG corruption blocks deletion", delegate { string path = ImageFile("final-corrupt.jpg"); string hash = FileHash(path); Converter.BeforeFinalVerify = p => File.WriteAllText(p, "bad final png"); Result result = Convert(path); Assert(result.Status == "FAILED" && FileHash(path) == hash, "Bad final output permitted deletion."); });
                Check("valid PNG with different pixels blocks deletion", delegate { string path = ImageFile("different-pixels.jpg"); string hash = FileHash(path); Converter.BeforeFinalVerify = p => { using (Bitmap bitmap = new Bitmap(31, 19)) bitmap.Save(p, ImageFormat.Png); }; Assert(Convert(path).Status == "FAILED" && FileHash(path) == hash, "Wrong pixels permitted deletion."); });
                Check("deletion failure retains both verified PNG and original", delegate { string path = ImageFile("delete-fail.jpg"); string hash = FileHash(path), pixels = DecodedHash(path); Converter.FailDelete = true; Result result = Convert(path); Assert(result.Status == "PNG_CREATED_ORIGINAL_KEPT" && FileHash(path) == hash && DecodedHash(result.Output) == pixels, "Deletion failure lost data."); });
                Check("log failure before deletion retains original", delegate { string path = ImageFile("log-fail.jpg"); string hash = FileHash(path); DurableLog log = new DurableLog(Path.Combine(root, "closed-log.csv")); log.Dispose(); Result result = Converter.ConvertOne(path, log, p => { }); Assert(result.Status == "FAILED" && FileHash(path) == hash && File.Exists(result.Output), "No durable log permitted deletion."); });
                Check("existing PNGs and folders are unchanged; non-images fail safely", delegate { string path = Path.Combine(root, "keep.png"); File.WriteAllText(path, "keep"); Assert(Convert(path).Status == "SKIPPED" && File.ReadAllText(path) == "keep", "PNG changed."); Assert(Convert(root).Status == "SKIPPED", "Folder wasn't skipped."); string other = Path.Combine(root, "not an image.bin"); File.WriteAllText(other, "not an image"); string hash = FileHash(other); Assert(Convert(other).Status == "FAILED" && FileHash(other) == hash, "Non-image was changed."); });
                Check("duplicate selections are processed once", delegate { string path = ImageFile("duplicate.jpg"); BatchSummary batch = Converter.Run(new[] { path, path }, Path.Combine(root, "duplicate logs"), n => { }, () => false); Assert(batch.Results.Count == 1 && batch.Replaced == 1, batch.Text); });
                Check("stop preserves unprocessed images", delegate { string path = ImageFile("stop.jpg"); string hash = FileHash(path); BatchSummary batch = Converter.Run(new[] { path }, Path.Combine(root, "stop logs"), n => { }, () => true); Assert(batch.Results[0].Status == "CANCELLED" && FileHash(path) == hash, "Stop changed source."); });
                Check("individual path longer than 400 characters", delegate { string path = ImageFile(Path.Combine(new string('a', 150), new string('b', 150), new string('c', 75), "long image & [1] 漢字.JPEG")); Assert(path.Length > 400, "Path wasn't long enough."); string pixels = DecodedHash(path); ReplaceOK(Convert(path), pixels); });
                Check("EXIF camera orientation 6 is baked into PNG correctly", delegate
                {
                    string path = ImageFile("orientation.jpg"); ExifOrientation(path, 6); string expected;
                    using (FileStream file = File.OpenRead(path)) using (Bitmap jpeg = (Bitmap)Image.FromStream(file)) { Assert(jpeg.PropertyIdList.Contains(0x0112), "EXIF fixture unreadable."); jpeg.RotateFlip(RotateFlipType.Rotate90FlipNone); expected = Converter.Pixels(jpeg); }
                    Result result = Convert(path); ReplaceOK(result, expected); using (Bitmap png = new Bitmap(result.Output)) Assert(png.Width == 19 && png.Height == 31, "Orientation dimensions wrong.");
                });
                Check("embedded ICC profile is retained and PNG verifies", delegate
                {
                    string profilePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "spool", "drivers", "color", "sRGB Color Space Profile.icm");
                    Assert(File.Exists(profilePath), "Windows sRGB test profile unavailable."); byte[] profile = File.ReadAllBytes(profilePath);
                    string path = ImageFile("icc.jpg"); InjectApp(path, 226, Encoding.ASCII.GetBytes("ICC_PROFILE\0").Concat(new byte[] { 1, 1 }).Concat(profile).ToArray());
                    string pixels = DecodedHash(path); Result result = Convert(path); ReplaceOK(result, pixels);
                    using (FileStream png = File.OpenRead(result.Output)) using (BinaryReader reader = new BinaryReader(png))
                    {
                        png.Position = 33; byte[] size = reader.ReadBytes(4); int length = (size[0] << 24) | (size[1] << 16) | (size[2] << 8) | size[3];
                        Assert(Encoding.ASCII.GetString(reader.ReadBytes(4)) == "iCCP", "PNG ICC chunk missing."); byte[] body = reader.ReadBytes(length); int start = Array.IndexOf(body, (byte)0) + 2;
                        using (MemoryStream zlib = new MemoryStream(body, start + 2, body.Length - start - 6)) using (DeflateStream inflater = new DeflateStream(zlib, CompressionMode.Decompress)) using (MemoryStream decoded = new MemoryStream())
                        { inflater.CopyTo(decoded); Assert(decoded.ToArray().SequenceEqual(profile), "ICC profile changed."); }
                    }
                });
                Check("incomplete ICC profile is rejected without deleting original", delegate { string path = ImageFile("bad-icc.jpg"); InjectApp(path, 226, Encoding.ASCII.GetBytes("ICC_PROFILE\0").Concat(new byte[] { 1, 2, 7, 8, 9 }).ToArray()); string hash = FileHash(path); Assert(Convert(path).Status == "FAILED" && FileHash(path) == hash, "Incomplete profile permitted deletion."); });
                Check("non-RGB ICC profile is preserved rather than changing colours", delegate
                {
                    string path = ImageFile("non-rgb-profile.jpg"); byte[] profile = new byte[128]; Encoding.ASCII.GetBytes("CMYK").CopyTo(profile, 16); Encoding.ASCII.GetBytes("acsp").CopyTo(profile, 36);
                    InjectApp(path, 226, Encoding.ASCII.GetBytes("ICC_PROFILE\0").Concat(new byte[] { 1, 1 }).Concat(profile).ToArray()); string hash = FileHash(path);
                    Assert(Convert(path).Status == "FAILED" && FileHash(path) == hash, "Non-RGB profile was silently dropped/misapplied.");
                });
                Check("PNG end marker and CRC checks reject damaged data", delegate
                {
                    string path = ImageFile("crc.jpg"); Result result = Convert(path); byte[] bytes = File.ReadAllBytes(result.Output);
                    bool truncated = false, badcrc = false;
                    try { using (MemoryStream stream = new MemoryStream(bytes.Take(bytes.Length - 12).ToArray())) Converter.CheckPng(stream); } catch (InvalidDataException) { truncated = true; }
                    bytes[29] ^= 1; try { using (MemoryStream stream = new MemoryStream(bytes)) Converter.CheckPng(stream); } catch (InvalidDataException) { badcrc = true; }
                    Assert(truncated && badcrc, "Damaged PNG was accepted.");
                });
                Check("COM selection transfer: 1,200 Unicode file paths, no command line", delegate
                { string[] paths = LargeSelection(); Assert(paths.Sum(p => p.Length) > 250000, "Selection too short."); List<string> received = ShellSelection.Read((ComDataObject)Data(paths)); Assert(received.SequenceEqual(paths), "COM selection truncated."); });
                Check("IDropTarget reports COPY, never Explorer MOVE", delegate
                {
                    string[] paths = LargeSelection(); List<string> selected = null; ShellDropTarget.Submit = p => selected = p;
                    ShellDropTarget target = new ShellDropTarget(); uint effect = 3; Native.Check(target.DragEnter((ComDataObject)Data(paths), 0, new PointL(), ref effect)); Assert(effect == 1, "DragEnter offered MOVE.");
                    effect = 3; Native.Check(target.Drop((ComDataObject)Data(paths), 0, new PointL(), ref effect)); Assert(effect == 1 && selected.SequenceEqual(paths), "Drop wasn't a complete COPY.");
                });
                Check("out-of-process COM activation and marshalled drop of 1,200 paths", delegate
                {
                    string file = Path.Combine(root, "com-transfer.txt");
                    ProcessStartInfo info = new ProcessStartInfo(Assembly.GetExecutingAssembly().Location, "--com-server \"" + file + "\"") { UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden };
                    using (Process child = Process.Start(info))
                    {
                        object obj = null;
                        try
                        {
                            WaitFor(file + ".ready", child); Guid clsid = TestClsid, iid = typeof(IDropTarget).GUID;
                            Native.Check(CoCreateInstance(ref clsid, IntPtr.Zero, 4, ref iid, out obj)); IDropTarget drop = (IDropTarget)obj; string[] paths = LargeSelection(); uint effect = 3;
                            Native.Check(drop.DragEnter((ComDataObject)Data(paths), 0, new PointL(), ref effect)); Assert(effect == 1, "Remote DragEnter wasn't COPY.");
                            effect = 3; Native.Check(drop.Drop((ComDataObject)Data(paths), 0, new PointL(), ref effect)); WaitFor(file, child);
                            Assert(effect == 1 && File.ReadAllLines(file).SequenceEqual(paths), "Remote drop selection changed.");
                        }
                        finally { if (obj != null && Marshal.IsComObject(obj)) Marshal.ReleaseComObject(obj); File.WriteAllText(file + ".quit", "quit"); Assert(child.WaitForExit(45000), "COM server didn't stop."); }
                    }
                });
                Check("right-click invocation accepts zero/link/move effects and never requests Explorer deletion", delegate
                {
                    string[] paths = LargeSelection();
                    foreach (uint requested in new uint[] { 0, 1, 2, 4, 7 })
                    {
                        List<string> selected = null; ShellDropTarget.Submit = p => selected = p;
                        ContextMenuTarget target = new ContextMenuTarget(); uint effect = requested;
                        Native.Check(target.DragEnter((ComDataObject)Data(paths), 0, new PointL(), ref effect));
                        Native.Check(target.Drop((ComDataObject)Data(paths), 0, new PointL(), ref effect));
                        Assert(effect == 0 && selected != null && selected.SequenceEqual(paths), "Menu command lost its selection or reported a file move.");
                    }
                });
                Check("production helper startup, COM readiness, persistence and clean stop", delegate
                {
                    Assert(args.Length >= 2, "Production executable argument is required.");
                    try
                    {
                        using (Mutex existing = Mutex.OpenExisting(Installer.MutexName)) { Installer.CheckRunningHelper(); Console.WriteLine("Existing installed helper was left running; startup/stop test skipped."); return; }
                    }
                    catch (WaitHandleCannotBeOpenedException) { }
                    using (EventWaitHandle ready = new EventWaitHandle(false, EventResetMode.ManualReset, Installer.ReadyName))
                    using (Process child = Process.Start(new ProcessStartInfo(Path.GetFullPath(args[1]), "--shell-server") { UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden }))
                    {
                        try
                        {
                            Assert(ready.WaitOne(60000), "Production helper did not become ready."); Installer.CheckRunningHelper();
                            Thread.Sleep(2100); Assert(!child.HasExited, "Idle helper stopped."); Installer.CheckRunningHelper();
                            using (Process duplicate = Process.Start(new ProcessStartInfo(Path.GetFullPath(args[1]), "--shell-server") { UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden }))
                            { Assert(duplicate.WaitForExit(30000) && duplicate.ExitCode == 0 && !child.HasExited, "Duplicate startup damaged the active helper."); }
                        }
                        finally
                        {
                            try { using (EventWaitHandle stop = EventWaitHandle.OpenExisting(Installer.StopName)) stop.Set(); } catch (WaitHandleCannotBeOpenedException) { }
                            Assert(child.WaitForExit(45000), "Production helper didn't stop cleanly.");
                        }
                        Assert(child.ExitCode == 0 && !ready.WaitOne(0), "Helper did not clear readiness and exit normally.");
                    }
                });
                Check("shortcut target is native EXE with no PowerShell/file-list arguments", delegate { string link = Path.Combine(root, "converter shortcut.lnk"), exe = Assembly.GetExecutingAssembly().Location; Installer.CreateLink(link, exe); Assert(Installer.LinkTarget(link) == exe, "Shortcut target wrong."); });
                Check("registry plan enables unlimited COM batch selection for both entry points", delegate
                {
                    string temporary = @"Software\PNGConverterBatchVerification_" + Guid.NewGuid().ToString("N");
                    using (RegistryKey parent = Registry.CurrentUser.CreateSubKey(temporary))
                    {
                        Installer.WriteRegistry(parent, @"C:\OneDrive - Test\PNGConverterBatch.exe", @"C:\Desktop\Batch.lnk");
                        using (RegistryKey verb = parent.OpenSubKey(Installer.Verb)) Assert((string)verb.GetValue("MultiSelectModel") == "Player", "Batch selection model missing.");
                        using (RegistryKey drop = parent.OpenSubKey(Installer.Verb + @"\DropTarget")) Assert((string)drop.GetValue("CLSID") == typeof(ContextMenuTarget).GUID.ToString("B"), "Menu isn't using the command handler.");
                        using (RegistryKey app = parent.OpenSubKey(Installer.AppPath)) Assert((string)app.GetValue("DropTarget") == typeof(ShellDropTarget).GUID.ToString("B"), "Shortcut isn't using COM.");
                        foreach (string keyPath in new[] { Installer.Clsid, Installer.MenuClsid })
                        {
                            using (RegistryKey key = parent.OpenSubKey(keyPath + @"\InprocServer32")) Assert(((string)key.GetValue("")).Contains("PNGConverterDrop_") && (string)key.GetValue("ThreadingModel") == "Apartment", "The native selection adapter is missing.");
                            Assert(parent.OpenSubKey(keyPath + @"\LocalServer32") == null, "Obsolete server startup remains.");
                        }
                        using (RegistryKey run = parent.OpenSubKey(Installer.RunKey)) Assert(run.GetValue(Installer.RunName) == null, "An unnecessary background startup remains.");
                        Assert(parent.OpenSubKey(Installer.Verb + @"\command") == null, "Legacy argument-list menu present.");
                    }
                    Registry.CurrentUser.DeleteSubKeyTree(temporary);
                });
                Check("uninstall handles shared 32/64-bit registry views and preserves unrelated startup", delegate
                {
                    string temporary = @"Software\PNGConverterBatchVerification_" + Guid.NewGuid().ToString("N");
                    List<RegistryKey> parents = new List<RegistryKey>(); string exe = @"C:\OneDrive - Test\PNGConverterBatch.exe";
                    try
                    {
                        foreach (RegistryView view in Installer.Views)
                            using (RegistryKey user = RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, view))
                            { RegistryKey parent = user.CreateSubKey(temporary); parents.Add(parent); Installer.WriteRegistry(parent, exe, @"C:\Desktop\Batch.lnk"); }
                        using (RegistryKey run = parents[0].OpenSubKey(Installer.RunKey, true)) run.SetValue("UnrelatedApp", "leave this alone");
                        Installer.RemoveRegistrations(parents, exe);
                        foreach (RegistryKey parent in parents)
                        {
                            Assert(parent.OpenSubKey(Installer.AppPath) == null && parent.OpenSubKey(Installer.Clsid) == null && parent.OpenSubKey(Installer.Verb) == null && parent.OpenSubKey(Installer.State) == null, "Registration was left behind.");
                            using (RegistryKey run = parent.OpenSubKey(Installer.RunKey)) Assert(run.GetValue(Installer.RunName) == null && (string)run.GetValue("UnrelatedApp") == "leave this alone", "Startup removal affected another app.");
                        }
                    }
                    finally
                    {
                        foreach (RegistryKey parent in parents) parent.Dispose();
                        foreach (RegistryView view in Installer.Views) using (RegistryKey user = RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, view)) user.DeleteSubKeyTree(temporary, false);
                    }
                });
                Check("BMP, TIFF and static GIF replace originals with exact decoded pixels", delegate
                {
                    foreach (ImageFormat format in new[] { ImageFormat.Bmp, ImageFormat.Tiff, ImageFormat.Gif })
                    {
                        string jpeg = ImageFile("native-source-" + format + ".jpg"), path = Path.Combine(root, "native-" + format + "." + format.ToString().ToLowerInvariant());
                        using (Bitmap image = new Bitmap(jpeg)) image.Save(path, format);
                        string pixels = DecodedHash(path); ReplaceOK(Convert(path), pixels);
                    }
                });
                Check("WebP, AVIF, JPEG XL, TGA, JPEG 2000 and ICO convert to verified PNG", delegate
                {
                    string jpeg = ImageFile("portable-source.jpg");
                    foreach (string format in new[] { "webp", "avif", "jxl", "tga", "jp2", "ico" })
                    {
                        string path = Path.Combine(root, "portable." + format); ImageEngine.Run(jpeg, path); Result result = Convert(path);
                        Assert(result.Status == "REPLACED" && !File.Exists(path) && File.Exists(result.Output), format + ": " + result.Detail);
                        using (FileStream png = File.OpenRead(result.Output)) Converter.CheckPng(png);
                    }
                });
                Check("SVG image is rendered and replaced only after PNG verification", delegate
                {
                    string path = Path.Combine(root, "vector.svg"); File.WriteAllText(path, "<svg xmlns='http://www.w3.org/2000/svg' width='29' height='17'><rect width='29' height='17' fill='#c48020'/></svg>");
                    Result result = Convert(path); Assert(result.Status == "REPLACED" && !File.Exists(path), result.Detail);
                    using (Bitmap image = new Bitmap(result.Output)) Assert(image.Width == 29 && image.Height == 17, "SVG dimensions changed.");
                });
                Check("animated GIF gets a PNG preview while its complete original is kept", delegate
                {
                    string a = ImageFile("animation-a.jpg"), b = ImageFile("animation-b.jpg", 31, 19), path = Path.Combine(root, "animation.gif");
                    ImageEngine.Run("-delay", "20", a, b, "-loop", "0", path); string hash = FileHash(path); Result result = Convert(path);
                    Assert(result.Status == "PNG_CREATED_ORIGINAL_KEPT" && FileHash(path) == hash && File.Exists(result.Output), result.Detail);
                });
                Check("16-bit TIFF retains full rendered precision in PNG", delegate
                {
                    string path = Path.Combine(root, "high precision.tiff"); ImageEngine.Run("-size", "43x19", "gradient:#19435b-#efb87a", "-depth", "16", path);
                    string expected = ImageEngine.PixelHash(path); Result result = Convert(path);
                    Assert(result.Status == "REPLACED" && ImageEngine.PixelHash(result.Output) == expected, result.Detail);
                });
                Check("folder permission command adds only the converter and keeps protection enabled", delegate
                {
                    string script = Protection.PermissionScript(@"C:\User's folder\PNGConverterBatch.exe");
                    Assert(script.Contains("Add-MpPreference -ControlledFolderAccessAllowedApplications") && script.Contains("User''s folder") && !script.Contains("Set-MpPreference") && !script.Contains("ExclusionPath") && script.Contains("$after.EnableControlledFolderAccess -ne $before.EnableControlledFolderAccess"), "Permission command changes broad protection or mishandles paths.");
                });
                Check("queued Unicode selection is complete, consumed once, and rejects arbitrary filenames", delegate
                {
                    Directory.CreateDirectory(QueuedSelection.DirectoryPath);
                    string name = "batch-" + Guid.NewGuid().ToString("N") + ".txt", file = Path.Combine(QueuedSelection.DirectoryPath, name);
                    string[] paths = LargeSelection();
                    File.WriteAllLines(file, new[] { "PNGConverterBatchSelectionV22" }.Concat(paths), Encoding.Unicode);
                    Assert(QueuedSelection.Read(name).SequenceEqual(paths) && !File.Exists(file), "The native selection was truncated or retained.");
                    foreach (string invalid in new[] { @"..\pictures.txt", @"C:\pictures.txt", "batch-" + Guid.NewGuid().ToString("N") + ".png" })
                    { bool rejected = false; try { QueuedSelection.Read(invalid); } catch (InvalidDataException) { rejected = true; } Assert(rejected, "An arbitrary file was accepted as a request."); }
                });
                Check("one-step installer scopes machine registration and folder permission to this converter", delegate
                {
                    string script = MachineSetup.Script();
                    Assert(script.Contains(MachineSetup.Executable.Replace("'", "''")), "Installed executable absent.");
                    Assert(script.Contains(typeof(ContextMenuTarget).GUID.ToString("B").ToUpperInvariant()) && script.Contains(typeof(ShellDropTarget).GUID.ToString("B").ToUpperInvariant()), "Both command/drag registrations are required.");
                    Assert(script.Contains("Registry64") && script.Contains("Registry32") && script.Contains("Get-FileHash") && script.Contains("PNGConverterDrop_x64.dll") && script.Contains("PNGConverterDrop_x86.dll") && script.Contains("InprocServer32"), "Machine registration/copy checks incomplete.");
                    Assert(script.Contains("Add-MpPreference -ControlledFolderAccessAllowedApplications $exe") && script.Contains("$after.EnableControlledFolderAccess -ne $before.EnableControlledFolderAccess"), "Permission must preserve protection.");
                    Assert(!script.Contains("ExclusionPath") && !script.Contains("Set-MpPreference") && !script.Contains("Remove-Item"), "Installer broadened scope.");
                });
                if (args.Length >= 2) Check("actual production process converts mixed formats and a copy of the reported failing JPEG", delegate
                {
                    string disposable = Path.Combine(Path.GetTempPath(), "PNGConverter-v21-process-test-" + Guid.NewGuid().ToString("N")); Directory.CreateDirectory(disposable);
                    string jpg = Path.Combine(disposable, "real process.jpg"); File.Copy(ImageFile("process-source.jpg"), jpg, false);
                    List<string> selection = new List<string> { jpg }; Dictionary<string, string> pixels = new Dictionary<string, string> { { jpg, DecodedHash(jpg) } };
                    foreach (string format in new[] { "bmp", "gif", "tiff", "webp", "avif", "jxl", "tga" })
                    { string path = Path.Combine(disposable, "real process." + format); ImageEngine.Run(jpg, path); selection.Add(path); }
                    string original = @"C:\Users\cam2t\Pictures\CLOTHING AND ACCESSSORIES\z.convert\beige_distressed_hood_scarf_set.jpg";
                    string originalHash = null;
                    if (File.Exists(original)) { originalHash = FileHash(original); string copy = Path.Combine(disposable, "reported JPEG copy.jpg"); File.Copy(original, copy, false); selection.Add(copy); pixels[copy] = DecodedHash(copy); }
                    string actualWebp = Directory.Exists(Path.GetDirectoryName(original)) ? Directory.GetFiles(Path.GetDirectoryName(original), "*.webp").FirstOrDefault() : null;
                    string webpHash = null, webpPixels = null, webpCopy = null;
                    if (actualWebp != null) { webpHash = FileHash(actualWebp); webpCopy = Path.Combine(disposable, "reported WebP copy.webp"); File.Copy(actualWebp, webpCopy, false); selection.Add(webpCopy); webpPixels = ImageEngine.PixelHash(webpCopy); }
                    string list = Path.Combine(disposable, "selection.txt"), logs = Path.Combine(disposable, "logs"); File.WriteAllLines(list, selection, new UTF8Encoding(true));
                    using (Process child = Process.Start(new ProcessStartInfo(Path.GetFullPath(args[1]), "--batch-list " + ImageEngine.Quote(list) + " " + ImageEngine.Quote(logs)) { UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden }))
                    { Assert(child.WaitForExit(180000), "Production process did not finish."); Assert(child.ExitCode == 0, "Production process failed; inspect " + logs); }
                    foreach (string source in selection) Assert(!File.Exists(source) && File.Exists(Path.ChangeExtension(source, ".png")), "Production process did not replace " + source);
                    Assert(Directory.GetFiles(disposable, "*.png").Length == selection.Count, "A same-stem output was overwritten.");
                    foreach (KeyValuePair<string, string> pair in pixels) Assert(DecodedHash(Path.ChangeExtension(pair.Key, ".png")) == pair.Value, "Production process changed JPEG pixels.");
                    if (originalHash != null) Assert(FileHash(original) == originalHash, "The real personal JPEG changed during testing.");
                    if (actualWebp != null) Assert(FileHash(actualWebp) == webpHash && ImageEngine.PixelHash(Path.ChangeExtension(webpCopy, ".png")) == webpPixels, "Actual WebP pixels changed or its personal source changed.");
                    Console.WriteLine("Actual-process data retained at: " + disposable);
                });
                if (args.Length >= 2)
                {
                    Check("shipped production executable: real conversion and replacement", delegate
                    {
                        Assembly production = Assembly.LoadFrom(Path.GetFullPath(args[1])); Type logType = production.GetType("PNGConverterBatch.DurableLog");
                        object log = Activator.CreateInstance(logType, BindingFlags.Instance | BindingFlags.NonPublic, null, new object[] { Path.Combine(root, "production.csv") }, null);
                        string path = ImageFile("production.jpg"), pixels = DecodedHash(path);
                        try
                        {
                            object result = production.GetType("PNGConverterBatch.Converter").GetMethod("ConvertOne", BindingFlags.NonPublic | BindingFlags.Static).Invoke(null, new object[] { path, log, (Action<string>)(s => { }) });
                            Type type = result.GetType(); string status = (string)type.GetField("Status", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(result), output = (string)type.GetField("Output", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(result);
                            Assert(status == "REPLACED" && !File.Exists(path) && DecodedHash(output) == pixels, "Production executable failed.");
                            Assert(production.GetType("PNGConverterBatch.Converter").GetField("FailDelete", BindingFlags.Static | BindingFlags.NonPublic) == null, "Test hooks leaked into production.");
                        }
                        finally { ((IDisposable)log).Dispose(); }
                    });
                }
            }
            finally { Native.OleUninitialize(); }
            report.Add("TOTAL: " + passed + " passed; " + failed + " failed."); report.Add("Test data retained at: " + root);
            File.WriteAllLines(Path.Combine(root, "TEST_RESULTS.txt"), report, new UTF8Encoding(true)); Console.WriteLine(report[report.Count - 2]); return failed == 0 ? 0 : 1;
        }
    }
}
