@echo off
setlocal
set "taskCompiler=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%taskCompiler%" set "taskCompiler=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
"%taskCompiler%" /nologo /codepage:65001 /define:TEST_BUILD /target:exe /main:PNGConverterBatch.Tests /platform:anycpu /reference:System.Drawing.dll /reference:System.Windows.Forms.dll /out:"%~dp0..\PNGConverterBatch.Tests.exe" /win32manifest:"%~dp0app.manifest" "%~dp0PNGConverterBatch.cs" "%~dp0ImageEngine.cs" "%~dp0Protection.cs" "%~dp0ProtectedCheck.cs" "%~dp0MachineSetup.cs" "%~dp0QueuedSelection.cs" "%~dp0Tests.cs"
if errorlevel 1 goto :failed
copy /y "%~dp0PNGConverterBatch.exe.config" "%~dp0..\PNGConverterBatch.Tests.exe.config" >nul
if errorlevel 1 goto :failed
"%~dp0..\PNGConverterBatch.Tests.exe" "%~dp0test-scratch-%RANDOM%-%RANDOM%" "%~dp0..\PNGConverterBatch.exe"
if errorlevel 1 goto :failed
echo All tests passed. Disposable test files and the report were retained.
pause
exit /b 0
:failed
echo Verification failed. See the error above.
pause
exit /b 1
