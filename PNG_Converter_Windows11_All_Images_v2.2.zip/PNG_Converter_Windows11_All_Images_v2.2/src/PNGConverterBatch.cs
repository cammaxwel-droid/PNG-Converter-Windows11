using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using Microsoft.Win32.SafeHandles;
using ComDataObject = System.Runtime.InteropServices.ComTypes.IDataObject;

[assembly: AssemblyTitle("PNG Converter Batch")]
[assembly: AssemblyDescription("Verified image conversion with Explorer batch transfer and protected-folder setup")]
[assembly: AssemblyVersion("2.2.0.0")]
[assembly: ComVisible(false)]

namespace PNGConverterBatch
{
    internal sealed class UsePortableDecoderException : Exception { }
    internal static class Native
    {
        internal const uint Read = 0x80000000, DeleteAccess = 0x10000;
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        internal static extern SafeFileHandle CreateFileW(string name, uint access, uint share, IntPtr security, uint disposition, uint flags, IntPtr template);
        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool SetFileInformationByHandle(SafeFileHandle handle, int infoClass, ref Disposition info, uint size);
        [StructLayout(LayoutKind.Sequential)] internal struct Disposition { [MarshalAs(UnmanagedType.Bool)] internal bool DeleteFile; }
        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool GetFileInformationByHandleEx(SafeFileHandle handle, int infoClass, out AttributeTag info, uint size);
        [StructLayout(LayoutKind.Sequential)] internal struct AttributeTag { internal uint Attributes, Tag; }
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        internal static extern bool MoveFileExW(string from, string to, uint flags);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        internal static extern bool DeleteFileW(string name);
        [DllImport("ole32.dll")] internal static extern int OleInitialize(IntPtr reserved);
        [DllImport("ole32.dll")] internal static extern void OleUninitialize();
        [DllImport("ole32.dll")] internal static extern int CoRegisterClassObject(ref Guid clsid, [MarshalAs(UnmanagedType.Interface)] IClassFactory factory, uint context, uint flags, out uint cookie);
        [DllImport("ole32.dll")] internal static extern int CoRevokeClassObject(uint cookie);
        [DllImport("ole32.dll")] internal static extern int CoResumeClassObjects();
        [DllImport("ole32.dll")] internal static extern int CoCreateInstance(ref Guid clsid, IntPtr outer, uint context, ref Guid iid, [MarshalAs(UnmanagedType.Interface)] out object result);
        [DllImport("ole32.dll")] internal static extern void ReleaseStgMedium(ref STGMEDIUM medium);
        [DllImport("shell32.dll")] internal static extern int SHCreateShellItemArrayFromDataObject(ComDataObject data, ref Guid iid, [MarshalAs(UnmanagedType.Interface)] out IShellItemArray items);
        [DllImport("shell32.dll", CharSet = CharSet.Unicode)] internal static extern uint DragQueryFileW(IntPtr drop, uint index, StringBuilder name, uint length);
        [DllImport("shell32.dll")] internal static extern void SHChangeNotify(uint eventId, uint flags, IntPtr item1, IntPtr item2);

        internal static string LongPath(string path)
        {
            if (path.StartsWith(@"\\?\", StringComparison.Ordinal)) return path;
            path = Path.GetFullPath(path);
            return path.StartsWith(@"\\", StringComparison.Ordinal) ? @"\\?\UNC\" + path.Substring(2) : @"\\?\" + path;
        }
        internal static string DisplayPath(string path)
        {
            if (path.StartsWith(@"\\?\UNC\", StringComparison.Ordinal)) return @"\\" + path.Substring(8);
            return path.StartsWith(@"\\?\", StringComparison.Ordinal) ? path.Substring(4) : path;
        }
        internal static void Check(int hr) { if (hr < 0) Marshal.ThrowExceptionForHR(hr); }
        internal static Exception Error(string action) { return new IOException(action + ": " + new Win32Exception(Marshal.GetLastWin32Error()).Message); }
        internal static void RejectFileLink(string path)
        {
            // Open the reparse point itself: reject symlinks, but allow OneDrive cloud tags.
            using (SafeFileHandle handle = CreateFileW(LongPath(path), 0, 7, IntPtr.Zero, 3, 0x00200000, IntPtr.Zero))
            {
                if (handle.IsInvalid) throw Error("Cannot inspect source");
                AttributeTag tag;
                if (!GetFileInformationByHandleEx(handle, 9, out tag, 8)) throw Error("Cannot inspect source attributes");
                if ((tag.Attributes & 0x10) != 0) throw new IOException("Select image files, rather than folders.");
                if (tag.Tag == 0xA000000C || tag.Tag == 0xA0000003) throw new IOException("Symbolic links are skipped; select the actual JPG/JPEG file.");
            }
        }
    }

    internal sealed class SourceLease : IDisposable
    {
        internal readonly FileStream Stream;
        internal readonly bool CanDelete;
        internal readonly string DeleteUnavailable;
        internal SourceLease(string path)
        {
            Native.RejectFileLink(path);
            SafeFileHandle handle = Native.CreateFileW(Native.LongPath(path), Native.Read | Native.DeleteAccess, 1, IntPtr.Zero, 3, 0x08000000, IntPtr.Zero);
            if (handle.IsInvalid)
            {
                DeleteUnavailable = new Win32Exception(Marshal.GetLastWin32Error()).Message;
                handle.Dispose();
                handle = Native.CreateFileW(Native.LongPath(path), Native.Read, 1, IntPtr.Zero, 3, 0x08000000, IntPtr.Zero);
                if (handle.IsInvalid) { Exception error = Native.Error("Cannot open source (it may be locked or unavailable in OneDrive)"); handle.Dispose(); throw error; }
                CanDelete = false;
            }
            else CanDelete = true;
            Stream = new FileStream(handle, FileAccess.Read);
        }
        internal void DeleteOriginal()
        {
            if (!CanDelete) throw new IOException("Original kept: " + DeleteUnavailable);
            Native.Disposition disposition = new Native.Disposition { DeleteFile = true };
            if (!Native.SetFileInformationByHandle(Stream.SafeFileHandle, 4, ref disposition, 4)) throw Native.Error("Original kept; Windows refused deletion");
            // This deletes the same locked file we decoded, without reopening its pathname.
        }
        public void Dispose() { Stream.Dispose(); }
    }

    internal sealed class Result
    {
        internal string Source, Output = "", Status = "FAILED", Detail = "", SourceHash = "", OutputHash = "", PixelHash = "";
    }
    internal sealed class Notice
    {
        internal int Index, Total;
        internal string Text;
        internal Notice(int index, int total, string text) { Index = index; Total = total; Text = text; }
    }
    internal sealed class BatchSummary
    {
        internal readonly List<Result> Results = new List<Result>();
        internal string LogPath, SummaryPath, Error;
        internal int Replaced { get { return Results.Count(r => r.Status == "REPLACED"); } }
        internal int Kept { get { return Results.Count(r => r.Status == "PNG_CREATED_ORIGINAL_KEPT"); } }
        internal int Failed { get { return Results.Count(r => r.Status == "FAILED"); } }
        internal int Skipped { get { return Results.Count(r => r.Status == "SKIPPED" || r.Status == "CANCELLED"); } }
        internal string Text { get { return String.Format("Completed: {0} replaced; {1} PNGs created with originals kept; {2} failed; {3} skipped/stopped.", Replaced, Kept, Failed, Skipped); } }
    }

    internal sealed class DurableLog : IDisposable
    {
        private FileStream file;
        private StreamWriter writer;
        internal DurableLog(string path)
        {
            file = new FileStream(Native.LongPath(path), FileMode.CreateNew, FileAccess.Write, FileShare.Read);
            writer = new StreamWriter(file, new UTF8Encoding(true));
            writer.WriteLine("TimeUtc,Status,Source,PNG,Detail,SourceSHA256,PNGSHA256,DecodedPixelsSHA256"); Flush();
        }
        private static string Q(string text) { return "\"" + (text ?? "").Replace("\"", "\"\"") + "\""; }
        internal void Write(Result result, string status, string detail)
        {
            writer.WriteLine(String.Join(",", new[] { Q(DateTime.UtcNow.ToString("o")), Q(status), Q(result.Source), Q(result.Output), Q(detail), Q(result.SourceHash), Q(result.OutputHash), Q(result.PixelHash) }));
            Flush();
        }
        private void Flush() { writer.Flush(); file.Flush(true); }
        public void Dispose() { writer.Dispose(); }
    }

    internal static class Converter
    {
#if TEST_BUILD
        internal static Action<string> BeforeWrite, BeforeTempVerify, BeforePublish, BeforeFinalVerify, BeforeDelete;
        internal static bool FailDelete;
        internal static void ResetHooks() { BeforeWrite = BeforeTempVerify = BeforePublish = BeforeFinalVerify = BeforeDelete = null; FailDelete = false; }
#endif
        internal static string Hash(Stream stream)
        {
            stream.Position = 0;
            using (SHA256 hash = SHA256.Create()) return BitConverter.ToString(hash.ComputeHash(stream)).Replace("-", "");
        }
        private static byte[] JpegProfile(Stream stream)
        {
            // Require both JPEG boundaries. A decoder may otherwise accept a truncated JPEG.
            if (stream.Length < 4) throw new InvalidDataException("Incomplete JPEG file.");
            stream.Position = stream.Length - 2;
            if (stream.ReadByte() != 255 || stream.ReadByte() != 217) throw new InvalidDataException("JPEG has no complete end marker; original kept.");
            stream.Position = 0;
            if (stream.ReadByte() != 255 || stream.ReadByte() != 216) throw new InvalidDataException("Missing JPEG start marker.");
            SortedDictionary<int, byte[]> parts = new SortedDictionary<int, byte[]>(); int expected = 0;
            while (stream.Position < stream.Length)
            {
                if (stream.ReadByte() != 255) throw new InvalidDataException("Invalid JPEG header.");
                int marker; do { marker = stream.ReadByte(); } while (marker == 255);
                if (marker < 0) throw new InvalidDataException("Truncated JPEG header.");
                if (marker == 218 || marker == 217) break;
                if (marker == 1 || (marker >= 208 && marker <= 215)) continue;
                int hi = stream.ReadByte(), lo = stream.ReadByte();
                if (hi < 0 || lo < 0) throw new InvalidDataException("Truncated JPEG segment.");
                int length = (hi << 8) | lo; length -= 2;
                if (length < 0 || length > stream.Length - stream.Position) throw new InvalidDataException("Truncated JPEG segment.");
                byte[] segment = new byte[length]; int read = 0;
                while (read < length) { int n = stream.Read(segment, read, length - read); if (n == 0) throw new InvalidDataException("Truncated JPEG segment."); read += n; }
                if (marker >= 192 && marker <= 207 && marker != 196 && marker != 200 && marker != 204 && length >= 6 && segment[5] == 4)
                    throw new UsePortableDecoderException();
                if (marker == 226 && length >= 14 && Encoding.ASCII.GetString(segment, 0, 12) == "ICC_PROFILE\0")
                {
                    int index = segment[12], total = segment[13];
                    if (index < 1 || total < index || (expected != 0 && total != expected) || parts.ContainsKey(index)) throw new InvalidDataException("Invalid JPEG colour profile; original kept.");
                    expected = total; parts.Add(index, segment.Skip(14).ToArray());
                }
            }
            if (parts.Count == 0) return null;
            if (parts.Count != expected) throw new InvalidDataException("Incomplete JPEG colour profile; original kept.");
            byte[] profile = parts.Values.SelectMany(p => p).ToArray();
            if (profile.Length < 128 || Encoding.ASCII.GetString(profile, 36, 4) != "acsp") throw new InvalidDataException("Invalid ICC profile header; original kept.");
            if (Encoding.ASCII.GetString(profile, 16, 4) != "RGB ") throw new UsePortableDecoderException();
            return profile;
        }
        private static void WriteBE(Stream stream, uint value)
        { stream.WriteByte((byte)(value >> 24)); stream.WriteByte((byte)(value >> 16)); stream.WriteByte((byte)(value >> 8)); stream.WriteByte((byte)value); }
        private static byte[] ProfileChunk(byte[] profile)
        {
            using (MemoryStream compressed = new MemoryStream())
            {
                // DeflateStream supplies raw DEFLATE. PNG iCCP requires the zlib wrapper.
                compressed.WriteByte(0x78); compressed.WriteByte(0x9C);
                using (DeflateStream deflater = new DeflateStream(compressed, CompressionLevel.Optimal, true)) deflater.Write(profile, 0, profile.Length);
                uint a = 1, b = 0; foreach (byte value in profile) { a = (a + value) % 65521; b = (b + a) % 65521; }
                WriteBE(compressed, (b << 16) | a);
                byte[] name = Encoding.ASCII.GetBytes("JPEG ICC\0\0"); byte[] body = name.Concat(compressed.ToArray()).ToArray(); byte[] type = Encoding.ASCII.GetBytes("iCCP");
                using (MemoryStream chunk = new MemoryStream())
                {
                    WriteBE(chunk, (uint)body.Length); chunk.Write(type, 0, type.Length); chunk.Write(body, 0, body.Length);
                    uint crc = 0xFFFFFFFF; foreach (byte value in type.Concat(body)) crc = CrcTable[(crc ^ value) & 255] ^ (crc >> 8);
                    WriteBE(chunk, crc ^ 0xFFFFFFFF); return chunk.ToArray();
                }
            }
        }
        internal static void SavePng(Bitmap image, FileStream file, byte[] profile)
        {
            if (profile == null) { image.Save(file, ImageFormat.Png); return; }
            // GDI+ doesn't reliably copy JPEG ICC data to PNG, so carry it explicitly.
            using (MemoryStream encoded = new MemoryStream())
            {
                image.Save(encoded, ImageFormat.Png); encoded.Position = 0;
                byte[] header = new byte[33]; if (encoded.Read(header, 0, 33) != 33) throw new InvalidDataException("PNG encoder produced no header.");
                file.Write(header, 0, header.Length); byte[] iccp = ProfileChunk(profile); file.Write(iccp, 0, iccp.Length);
                encoded.CopyTo(file);
            }
        }
        internal static Bitmap Canonical(Bitmap image)
        {
            ushort orientation = 1;
            if (image.PropertyIdList.Contains(0x0112))
            {
                byte[] value = image.GetPropertyItem(0x0112).Value;
                if (value.Length >= 2) orientation = BitConverter.ToUInt16(value, 0);
            }
            RotateFlipType[] transforms = { RotateFlipType.RotateNoneFlipNone, RotateFlipType.RotateNoneFlipNone, RotateFlipType.RotateNoneFlipX, RotateFlipType.Rotate180FlipNone, RotateFlipType.Rotate180FlipX, RotateFlipType.Rotate90FlipX, RotateFlipType.Rotate90FlipNone, RotateFlipType.Rotate270FlipX, RotateFlipType.Rotate270FlipNone };
            if (orientation >= 2 && orientation <= 8) image.RotateFlip(transforms[orientation]);
            Bitmap canonical = new Bitmap(image.Width, image.Height, PixelFormat.Format32bppArgb);
            try
            {
                float x = image.HorizontalResolution, y = image.VerticalResolution;
                if (x > 0 && y > 0 && !Single.IsInfinity(x) && !Single.IsInfinity(y)) canonical.SetResolution(x, y);
                Rectangle bounds = new Rectangle(0, 0, image.Width, image.Height);
                BitmapData input = null, output = null;
                try
                {
                    input = image.LockBits(bounds, ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
                    output = canonical.LockBits(bounds, ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
                    byte[] row = new byte[checked(image.Width * 4)];
                    for (int i = 0; i < image.Height; i++)
                    {
                        Marshal.Copy(IntPtr.Add(input.Scan0, i * input.Stride), row, 0, row.Length);
                        Marshal.Copy(row, 0, IntPtr.Add(output.Scan0, i * output.Stride), row.Length);
                    }
                }
                finally { if (input != null) image.UnlockBits(input); if (output != null) canonical.UnlockBits(output); }
                return canonical;
            }
            catch { canonical.Dispose(); throw; }
        }
        internal static string Pixels(Bitmap image)
        {
            BitmapData data = image.LockBits(new Rectangle(0, 0, image.Width, image.Height), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            try
            {
                using (SHA256 hash = SHA256.Create())
                {
                    byte[] dims = BitConverter.GetBytes(image.Width).Concat(BitConverter.GetBytes(image.Height)).ToArray();
                    hash.TransformBlock(dims, 0, dims.Length, dims, 0);
                    byte[] row = new byte[checked(image.Width * 4)];
                    for (int i = 0; i < image.Height; i++)
                    {
                        Marshal.Copy(IntPtr.Add(data.Scan0, i * data.Stride), row, 0, row.Length);
                        hash.TransformBlock(row, 0, row.Length, row, 0);
                    }
                    hash.TransformFinalBlock(new byte[0], 0, 0);
                    return BitConverter.ToString(hash.Hash).Replace("-", "");
                }
            }
            finally { image.UnlockBits(data); }
        }
        private static uint ReadBE(BinaryReader reader)
        {
            byte[] b = reader.ReadBytes(4); if (b.Length != 4) throw new InvalidDataException("Truncated PNG chunk.");
            return ((uint)b[0] << 24) | ((uint)b[1] << 16) | ((uint)b[2] << 8) | b[3];
        }
        private static readonly uint[] CrcTable = MakeCrcTable();
        private static uint[] MakeCrcTable()
        {
            uint[] table = new uint[256];
            for (uint n = 0; n < 256; n++) { uint c = n; for (int k = 0; k < 8; k++) c = (c & 1) != 0 ? 0xEDB88320 ^ (c >> 1) : c >> 1; table[n] = c; }
            return table;
        }
        internal static void CheckPng(Stream stream)
        {
            stream.Position = 0;
            using (BinaryReader reader = new BinaryReader(stream, Encoding.ASCII, true))
            {
                byte[] signature = { 137, 80, 78, 71, 13, 10, 26, 10 };
                if (!reader.ReadBytes(8).SequenceEqual(signature)) throw new InvalidDataException("Not a PNG file.");
                bool ihdr = false, idat = false, iend = false;
                byte[] buffer = new byte[65536];
                while (stream.Position < stream.Length)
                {
                    uint size = ReadBE(reader);
                    byte[] type = reader.ReadBytes(4); if (type.Length != 4) throw new InvalidDataException("Incomplete PNG.");
                    string name = Encoding.ASCII.GetString(type);
                    if (!ihdr && (name != "IHDR" || size != 13)) throw new InvalidDataException("Missing PNG header.");
                    if (size > stream.Length - stream.Position - 4) throw new InvalidDataException("Truncated PNG data.");
                    uint crc = 0xFFFFFFFF;
                    foreach (byte b in type) crc = CrcTable[(crc ^ b) & 255] ^ (crc >> 8);
                    long remaining = size;
                    while (remaining > 0)
                    {
                        int count = stream.Read(buffer, 0, (int)Math.Min(remaining, buffer.Length));
                        if (count == 0) throw new InvalidDataException("Truncated PNG data.");
                        for (int i = 0; i < count; i++) crc = CrcTable[(crc ^ buffer[i]) & 255] ^ (crc >> 8);
                        remaining -= count;
                    }
                    if ((crc ^ 0xFFFFFFFF) != ReadBE(reader)) throw new InvalidDataException("PNG checksum failed.");
                    if (name == "IHDR") { if (ihdr) throw new InvalidDataException("Duplicate PNG header."); ihdr = true; }
                    if (name == "IDAT") idat = true;
                    if (name == "IEND") { if (size != 0) throw new InvalidDataException("Invalid PNG end."); iend = true; break; }
                }
                if (!ihdr || !idat || !iend || stream.Position != stream.Length) throw new InvalidDataException("Incomplete PNG or unexpected trailing data.");
            }
        }
        internal static void VerifyPng(Stream stream, int width, int height, string pixels, byte[] profile = null)
        {
            CheckPng(stream);
            if (profile != null)
            {
                byte[] expected = ProfileChunk(profile), actual = new byte[expected.Length]; stream.Position = 33;
                int count = 0; while (count < actual.Length) { int n = stream.Read(actual, count, actual.Length - count); if (n == 0) break; count += n; }
                if (count != actual.Length || !actual.SequenceEqual(expected)) throw new InvalidDataException("PNG colour profile differs from the JPEG; original kept.");
            }
            stream.Position = 0;
            using (Bitmap decoded = (Bitmap)Image.FromStream(stream, false, true))
            {
                if (decoded.RawFormat.Guid != ImageFormat.Png.Guid || decoded.Width != width || decoded.Height != height || Pixels(decoded) != pixels)
                    throw new InvalidDataException("PNG verification failed: dimensions or decoded pixels differ.");
            }
        }
        private static string Publish(string temporary, string source)
        {
            string stem = Path.GetFileNameWithoutExtension(source);
            for (int suffix = 0; suffix < 1000000; suffix++)
            {
                string label = suffix == 0 ? "" : " (converted " + suffix + ")";
                int keep = Math.Min(stem.Length, 255 - label.Length - 4);
                if (keep < stem.Length && keep > 0 && Char.IsHighSurrogate(stem[keep - 1])) keep--;
                string output = Path.Combine(Path.GetDirectoryName(source), stem.Substring(0, keep) + label + ".png");
                if (Native.MoveFileExW(Native.LongPath(temporary), Native.LongPath(output), 8)) return output;
                int error = Marshal.GetLastWin32Error();
                if (error != 80 && error != 183) throw new IOException("Cannot publish PNG: " + new Win32Exception(error).Message);
            }
            throw new IOException("No available PNG filename; original kept.");
        }
        private static PreparedImage Prepare(Stream stream, string path)
        {
            stream.Position = 0; int a = stream.ReadByte(), b = stream.ReadByte(); byte[] profile = null;
            if (a == 255 && b == 216)
            {
                try { profile = JpegProfile(stream); }
                catch (UsePortableDecoderException) { return ImageEngine.Prepare(stream, path); }
            }
            stream.Position = 0; Image decoded;
            try { decoded = Image.FromStream(stream, false, true); }
            catch (ArgumentException) { return ImageEngine.Prepare(stream, path); }
            catch (OutOfMemoryException) { return ImageEngine.Prepare(stream, path); }
            using (decoded)
            {
                Bitmap bitmap = decoded as Bitmap;
                if (bitmap == null || Image.GetPixelFormatSize(bitmap.PixelFormat) > 32) return ImageEngine.Prepare(stream, path);
                if (decoded.PropertyIdList.Contains(0x0102))
                { byte[] bits = decoded.GetPropertyItem(0x0102).Value; if (bits.Length >= 2 && BitConverter.ToUInt16(bits, 0) > 8) return ImageEngine.Prepare(stream, path); }
                int frames = 1;
                foreach (Guid dimension in decoded.FrameDimensionsList) frames = Math.Max(frames, decoded.GetFrameCount(new FrameDimension(dimension)));
                if (frames > 1) return ImageEngine.Prepare(stream, path);
                if (profile == null && decoded.PropertyIdList.Contains(0x8773))
                {
                    profile = decoded.GetPropertyItem(0x8773).Value;
                    if (profile.Length < 128 || Encoding.ASCII.GetString(profile, 36, 4) != "acsp") throw new InvalidDataException("Invalid embedded ICC profile. Original kept.");
                    if (Encoding.ASCII.GetString(profile, 16, 4) != "RGB ") return ImageEngine.Prepare(stream, path);
                }
                PreparedImage prepared = new PreparedImage { Raster = Canonical(bitmap), Profile = profile };
                prepared.Width = prepared.Raster.Width; prepared.Height = prepared.Raster.Height; prepared.PixelHash = Pixels(prepared.Raster); return prepared;
            }
        }
        internal static Result ConvertOne(string path, DurableLog log, Action<string> progress)
        {
            Result result = new Result { Source = Native.DisplayPath(path) };
            string temporary = null; bool ownsTemporary = false; string stage = "Reading source";
            try
            {
                string extension = Path.GetExtension(path);
                if (extension.Equals(".png", StringComparison.OrdinalIgnoreCase))
                { result.Status = "SKIPPED"; result.Detail = "Already named PNG; unchanged, with no duplicate created."; return result; }
                path = Path.GetFullPath(path); result.Source = Native.DisplayPath(path);
                if (Directory.Exists(Native.LongPath(path))) { result.Status = "SKIPPED"; result.Detail = "Folders are skipped. Select the image files inside."; return result; }
                using (SourceLease original = new SourceLease(path))
                {
                    progress("Reading source; OneDrive may need to download it...");
                    result.SourceHash = Hash(original.Stream);
                    using (PreparedImage prepared = Prepare(original.Stream, path))
                    {
                            result.PixelHash = prepared.PixelHash;
                            temporary = Path.Combine(Path.GetDirectoryName(path), ".png-converter-" + Guid.NewGuid().ToString("N") + ".tmp");
                            stage = "Creating PNG in the source folder";
                            progress("Writing and verifying PNG...");
#if TEST_BUILD
                            if (BeforeWrite != null) BeforeWrite(temporary);
#endif
                            using (FileStream output = new FileStream(Native.LongPath(temporary), FileMode.CreateNew, FileAccess.Write, FileShare.None))
                            { ownsTemporary = true; ImageEngine.Save(prepared, output); output.Flush(true); }
                            stage = "Verifying temporary PNG";
#if TEST_BUILD
                            if (BeforeTempVerify != null) BeforeTempVerify(temporary);
#endif
                            using (FileStream check = new FileStream(Native.LongPath(temporary), FileMode.Open, FileAccess.Read, FileShare.Read))
                                ImageEngine.Verify(prepared, check, temporary);
#if TEST_BUILD
                            if (BeforePublish != null) BeforePublish(path);
#endif
                            stage = "Publishing PNG"; result.Output = Publish(temporary, path); temporary = null;
#if TEST_BUILD
                            if (BeforeFinalVerify != null) BeforeFinalVerify(result.Output);
#endif
                            // Keep the final PNG locked against edits/removal until deletion is committed.
                            using (FileStream final = new FileStream(Native.LongPath(result.Output), FileMode.Open, FileAccess.Read, FileShare.Read))
                            {
                                stage = "Verifying final PNG"; ImageEngine.Verify(prepared, final, result.Output);
                                result.OutputHash = Hash(final);
                                // A durable verification record is mandatory before any deletion.
                                log.Write(result, "VERIFIED", "Final PNG flushed, complete, reopened, and decoded pixels matched. Original is still locked.");
                                progress("PNG verified; replacing original...");
                                try
                                {
#if TEST_BUILD
                                    if (BeforeDelete != null) BeforeDelete(path);
                                    if (FailDelete) throw new IOException("Simulated deletion failure.");
#endif
                                    if (prepared.KeepReason != null) { result.Status = "PNG_CREATED_ORIGINAL_KEPT"; result.Detail = prepared.KeepReason; }
                                    else { original.DeleteOriginal(); result.Status = "REPLACED"; result.Detail = "PNG verified. Original deletion committed on its locked handle."; }
                                }
                                catch (Exception error) { result.Status = "PNG_CREATED_ORIGINAL_KEPT"; result.Detail = error.Message; }
                            }
                    }
                }
            }
            catch (Exception error) { result.Status = "FAILED"; result.Detail = Protection.Explain(error, stage, path) + " Original kept."; }
            finally
            {
                if (ownsTemporary && temporary != null && !Native.DeleteFileW(Native.LongPath(temporary)))
                    result.Detail += " Temporary output could not be removed: " + temporary;
            }
            return result;
        }
        internal static BatchSummary Run(IEnumerable<string> selection, string logDirectory, Action<Notice> progress, Func<bool> stopped)
        {
            BatchSummary summary = new BatchSummary();
            List<string> paths = selection.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            Directory.CreateDirectory(Native.LongPath(logDirectory));
            string stamp = DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss") + "_" + Guid.NewGuid().ToString("N").Substring(0, 8);
            summary.LogPath = Path.Combine(logDirectory, "PNG_" + stamp + ".csv");
            summary.SummaryPath = Path.Combine(logDirectory, "PNG_" + stamp + "_summary.txt");
            using (DurableLog log = new DurableLog(summary.LogPath))
            {
                for (int i = 0; i < paths.Count; i++)
                {
                    int current = i + 1;
                    progress(new Notice(current, paths.Count, "[" + current + "/" + paths.Count + "] " + paths[i]));
                    Result result;
                    if (stopped()) result = new Result { Source = paths[i], Status = "CANCELLED", Detail = "Stopped before this file; unchanged." };
                    else result = ConvertOne(paths[i], log, stage => progress(new Notice(current, paths.Count, stage)));
                    summary.Results.Add(result);
                    try { log.Write(result, result.Status, result.Detail); }
                    catch (Exception error) { summary.Error = "Logging failed; remaining files were not processed. " + error.Message; break; }
                    progress(new Notice(current, paths.Count, result.Status + ": " + result.Detail + (String.IsNullOrEmpty(result.Output) ? "" : Environment.NewLine + "PNG: " + result.Output)));
                }
            }
            string text = summary.Text + Environment.NewLine + "Log: " + summary.LogPath + Environment.NewLine + (summary.Error ?? "") + Environment.NewLine;
            try { File.WriteAllText(Native.LongPath(summary.SummaryPath), text, new UTF8Encoding(true)); }
            catch (Exception error) { summary.Error = "Summary file could not be written: " + error.Message; }
            return summary;
        }
    }

    // Standard Windows interfaces are marshalled across processes; Explorer loads no converter DLL.
    [ComVisible(true), Guid("00000122-0000-0000-C000-000000000046"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IDropTarget
    {
        [PreserveSig] int DragEnter([MarshalAs(UnmanagedType.Interface)] ComDataObject data, uint keyState, PointL point, ref uint effect);
        [PreserveSig] int DragOver(uint keyState, PointL point, ref uint effect);
        [PreserveSig] int DragLeave();
        [PreserveSig] int Drop([MarshalAs(UnmanagedType.Interface)] ComDataObject data, uint keyState, PointL point, ref uint effect);
    }
    [StructLayout(LayoutKind.Sequential)] public struct PointL { public int X, Y; }
    [ComVisible(true), Guid("00000001-0000-0000-C000-000000000046"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IClassFactory
    {
        [PreserveSig] int CreateInstance(IntPtr outer, ref Guid iid, out IntPtr instance);
        [PreserveSig] int LockServer([MarshalAs(UnmanagedType.Bool)] bool locked);
    }
    [ComImport, Guid("43826D1E-E718-42EE-BC55-A1E261C37BFE"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IShellItem
    {
        void BindToHandler(IntPtr bind, ref Guid handler, ref Guid iid, out IntPtr result);
        void GetParent(out IShellItem parent);
        void GetDisplayName(uint nameType, out IntPtr name);
        void GetAttributes(uint mask, out uint attrs);
        void Compare(IShellItem other, uint hint, out int order);
    }
    [ComImport, Guid("B63EA76D-1F85-456F-A19C-48159EFA858B"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IShellItemArray
    {
        void BindToHandler(IntPtr bind, ref Guid handler, ref Guid iid, out IntPtr result);
        void GetPropertyStore(uint flags, ref Guid iid, out IntPtr result);
        void GetPropertyDescriptionList(IntPtr key, ref Guid iid, out IntPtr result);
        void GetAttributes(uint flags, uint mask, out uint attrs);
        void GetCount(out uint count);
        void GetItemAt(uint index, out IShellItem item);
        void EnumItems(out IntPtr enumerator);
    }
    internal static class ShellSelection
    {
        internal static bool HasFiles(ComDataObject data)
        {
            FORMATETC format = new FORMATETC { cfFormat = 15, dwAspect = DVASPECT.DVASPECT_CONTENT, lindex = -1, tymed = TYMED.TYMED_HGLOBAL };
            if (data.QueryGetData(ref format) == 0) return true;
            format.cfFormat = (short)DataFormats.GetFormat("Shell IDList Array").Id;
            return data.QueryGetData(ref format) == 0;
        }
        internal static List<string> Read(ComDataObject data)
        {
            Guid iid = typeof(IShellItemArray).GUID; IShellItemArray array;
            if (Native.SHCreateShellItemArrayFromDataObject(data, ref iid, out array) >= 0)
            {
                try
                {
                    uint count; array.GetCount(out count); List<string> paths = new List<string>();
                    for (uint i = 0; i < count; i++)
                    {
                        IShellItem item; array.GetItemAt(i, out item); IntPtr name = IntPtr.Zero;
                        try { item.GetDisplayName(0x80058000, out name); paths.Add(Marshal.PtrToStringUni(name)); }
                        finally { if (name != IntPtr.Zero) Marshal.FreeCoTaskMem(name); Marshal.ReleaseComObject(item); }
                    }
                    return paths;
                }
                finally { Marshal.ReleaseComObject(array); }
            }
            FORMATETC format = new FORMATETC { cfFormat = 15, dwAspect = DVASPECT.DVASPECT_CONTENT, lindex = -1, tymed = TYMED.TYMED_HGLOBAL };
            STGMEDIUM medium; data.GetData(ref format, out medium);
            try
            {
                uint count = Native.DragQueryFileW(medium.unionmember, UInt32.MaxValue, null, 0);
                List<string> paths = new List<string>();
                for (uint i = 0; i < count; i++)
                {
                    uint size = Native.DragQueryFileW(medium.unionmember, i, null, 0);
                    StringBuilder name = new StringBuilder(checked((int)size + 1));
                    if (Native.DragQueryFileW(medium.unionmember, i, name, size + 1) != size) throw new IOException("Windows supplied an incomplete filename. Nothing was converted.");
                    paths.Add(name.ToString());
                }
                return paths;
            }
            finally { Native.ReleaseStgMedium(ref medium); }
        }
    }
    [ComVisible(true), ClassInterface(ClassInterfaceType.None), Guid("B933FB76-015D-4A3B-8BA8-E4855584460A")]
    public sealed class ShellDropTarget : IDropTarget
    {
        public ShellDropTarget() { ServerTrace.Write("Drag handler created."); }
        internal static Action<List<string>> Submit;
        internal static Action<Exception> ReportError;
        private bool accepts;
        public int DragEnter(ComDataObject data, uint keyState, PointL point, ref uint effect)
        {
            try { accepts = ShellSelection.HasFiles(data); effect = accepts ? effect & 1u : 0; return 0; }
            catch { accepts = false; effect = 0; return 0; }
        }
        public int DragOver(uint keyState, PointL point, ref uint effect) { effect = accepts ? effect & 1u : 0; return 0; }
        public int DragLeave() { accepts = false; return 0; }
        public int Drop(ComDataObject data, uint keyState, PointL point, ref uint effect)
        {
            try
            {
                if ((effect & 1) == 0) { effect = 0; return 0; }
                // Copy paths before returning: the shell data object expires after Drop.
                List<string> paths = ShellSelection.Read(data);
                if (paths.Count == 0) throw new IOException("No file paths were received. Nothing was converted.");
                Submit(paths);
                effect = 1; // Never report MOVE: Explorer must not delete any source on our behalf.
                return 0;
            }
            catch (Exception error) { effect = 0; if (ReportError != null) ReportError(error); return Marshal.GetHRForException(error); }
        }
    }
    // A menu command can arrive with no COPY effect. It must consume the selection
    // regardless of that flag and must never request source deletion by Explorer.
    [ComVisible(true), ClassInterface(ClassInterfaceType.None), Guid("936BE8B2-82F3-4D3E-A814-154754A5B39D")]
    public sealed class ContextMenuTarget : IDropTarget
    {
        public ContextMenuTarget() { ServerTrace.Write("Menu handler created."); }
        public int DragEnter(ComDataObject data, uint keyState, PointL point, ref uint effect)
        { try { if (!ShellSelection.HasFiles(data)) effect = 0; return 0; } catch { effect = 0; return 0; } }
        public int DragOver(uint keyState, PointL point, ref uint effect) { return 0; }
        public int DragLeave() { return 0; }
        public int Drop(ComDataObject data, uint keyState, PointL point, ref uint effect)
        {
            effect = 0;
            try
            {
                List<string> paths = ShellSelection.Read(data);
                if (paths.Count == 0) throw new IOException("No file paths were received. Nothing was converted.");
                ShellDropTarget.Submit(paths); return 0;
            }
            catch (Exception error) { if (ShellDropTarget.ReportError != null) ShellDropTarget.ReportError(error); return Marshal.GetHRForException(error); }
        }
    }
    [ComVisible(true), ClassInterface(ClassInterfaceType.None)]
    public sealed class DropFactory : IClassFactory
    {
        private readonly bool menu;
        public DropFactory() { }
        internal DropFactory(bool menuCommand) { menu = menuCommand; }
        public int CreateInstance(IntPtr outer, ref Guid iid, out IntPtr instance)
        {
            ServerTrace.Write("Factory requested: " + (menu ? "menu" : "drag") + "; interface " + iid);
            instance = IntPtr.Zero; if (outer != IntPtr.Zero) return unchecked((int)0x80040110);
            IntPtr unknown = Marshal.GetIUnknownForObject(menu ? (object)new ContextMenuTarget() : new ShellDropTarget());
            try { return Marshal.QueryInterface(unknown, ref iid, out instance); }
            finally { Marshal.Release(unknown); }
        }
        public int LockServer(bool locked) { return 0; }
    }

    internal sealed class ProgressWindow : Form
    {
        private readonly TextBox output = new TextBox();
        private readonly Label status = new Label();
        private readonly ProgressBar bar = new ProgressBar();
        private readonly Button stop = new Button(), logs = new Button(), close = new Button(), permission = new Button();
        private volatile bool stopped;
        private bool running = true;
        private string logFile;
        internal ProgressWindow(List<string> paths)
        {
            Text = "Images to PNG - " + paths.Count + " selected"; Width = 950; Height = 560; MinimumSize = new Size(780, 380); StartPosition = FormStartPosition.CenterScreen;
            Font = new Font("Segoe UI", 10); Padding = new Padding(12);
            TableLayoutPanel layout = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 4, ColumnCount = 1 };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 44)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 26)); layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 46));
            status.Dock = DockStyle.Fill; status.Text = "Starting batch. Originals are deleted only after the PNG is verified.";
            bar.Dock = DockStyle.Fill; output.Dock = DockStyle.Fill; output.Multiline = true; output.ReadOnly = true; output.ScrollBars = ScrollBars.Both; output.WordWrap = false; output.Font = new Font("Consolas", 10);
            FlowLayoutPanel buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight };
            stop.Text = "Stop after this file"; stop.AutoSize = true; logs.Text = "Open log folder"; logs.AutoSize = true; logs.Enabled = false; close.Text = "Close"; close.AutoSize = true; close.Enabled = false;
            stop.Click += delegate { stopped = true; stop.Enabled = false; status.Text = "Finishing this file safely. Remaining files will be left unchanged."; };
            close.Click += delegate { Close(); }; logs.Click += delegate { Process.Start(new ProcessStartInfo("explorer.exe", "/select,\"" + logFile + "\"") { UseShellExecute = true }); };
            permission.Text = "Allow folder access"; permission.AutoSize = true; permission.Enabled = false;
            permission.Click += delegate { try { MessageBox.Show(Protection.AllowInstalled(), "PNG Converter folder access"); } catch (Exception error) { MessageBox.Show(error.Message, "Folder access was not changed", MessageBoxButtons.OK, MessageBoxIcon.Error); } };
            buttons.Controls.AddRange(new Control[] { stop, logs, permission, close });
            layout.Controls.Add(status, 0, 0); layout.Controls.Add(bar, 0, 1); layout.Controls.Add(output, 0, 2); layout.Controls.Add(buttons, 0, 3); Controls.Add(layout);
            FormClosing += delegate(object sender, FormClosingEventArgs e) { if (running) { stopped = true; e.Cancel = true; status.Text = "Finishing this file safely; the window can close when the summary appears."; } };
            Shown += async delegate
            {
                try
                {
                    BatchSummary summary = await Task.Run(() => Converter.Run(paths, Installer.LogDirectory, message =>
                    {
                        BeginInvoke((Action)delegate { bar.Maximum = Math.Max(1, message.Total); bar.Value = Math.Min(message.Index, bar.Maximum); status.Text = "File " + message.Index + " of " + message.Total; output.AppendText(message.Text + Environment.NewLine); });
                    }, () => stopped));
                    logFile = summary.LogPath; output.AppendText(Environment.NewLine + summary.Text + Environment.NewLine + "Log: " + summary.LogPath + Environment.NewLine + "Summary: " + summary.SummaryPath + Environment.NewLine + (summary.Error ?? ""));
                    status.Text = summary.Text; logs.Enabled = File.Exists(logFile);
                }
                catch (Exception error) { status.Text = "Batch stopped."; output.AppendText(Environment.NewLine + "ERROR: " + error.Message + Environment.NewLine + "Files not yet converted were left unchanged."); }
                finally { running = false; stop.Enabled = false; close.Enabled = true; permission.Enabled = Protection.Enabled; }
            };
        }
    }

    internal sealed class ConverterContext : ApplicationContext
    {
        private readonly Control dispatcher = new Control();
        private readonly System.Windows.Forms.Timer idle = new System.Windows.Forms.Timer();
        private readonly RegistrationServices registrations = new RegistrationServices();
        private int cookie, menuCookie;
        private int windows;
        private DateTime lastUse = DateTime.UtcNow;
        private readonly bool resident;
        private readonly EventWaitHandle ready, shutdown;
        private bool shuttingDown;
        internal ConverterContext(bool embedding, bool keepRunning, string[] arguments)
        {
            ServerTrace.Write("Context starting: embedding=" + embedding + "; resident=" + keepRunning);
            resident = keepRunning;
            dispatcher.CreateControl(); IntPtr ensureHandle = dispatcher.Handle;
            ShellDropTarget.Submit = paths => dispatcher.BeginInvoke((Action)delegate { ShowBatch(paths); });
            ShellDropTarget.ReportError = error => dispatcher.BeginInvoke((Action)delegate { MessageBox.Show(error.Message, "PNG Converter - no conversion started", MessageBoxButtons.OK, MessageBoxIcon.Error); });
            if (resident)
            {
                ready = new EventWaitHandle(false, EventResetMode.ManualReset, Installer.ReadyName);
                shutdown = new EventWaitHandle(false, EventResetMode.ManualReset, Installer.StopName);
                shutdown.Reset();
            }
            // Publish factories only after the Windows Forms message loop is active.
            // A COM-launched STA must be able to dispatch activation immediately.
            if (embedding) dispatcher.BeginInvoke((Action)delegate
            {
                try
                {
                    ServerTrace.Write("Windows message loop startup callback running.");
                    RegistrationConnectionType flags = RegistrationConnectionType.MultipleUse | RegistrationConnectionType.Suspended;
                    cookie = registrations.RegisterTypeForComClients(typeof(ShellDropTarget), RegistrationClassContext.LocalServer, flags);
                    menuCookie = registrations.RegisterTypeForComClients(typeof(ContextMenuTarget), RegistrationClassContext.LocalServer, flags);
                    Native.Check(Native.CoResumeClassObjects());
                    if (ready != null) ready.Set();
                    ServerTrace.Write("Both factories registered; activation resumed; ready signal set.");
                }
                catch (Exception error)
                {
                    ServerTrace.Write("Handler startup failed: " + error);
                    MessageBox.Show(error.Message, "PNG Converter - startup failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    ExitThread();
                }
            });
            idle.Interval = 1000;
            idle.Tick += delegate
            {
                if (resident && shutdown.WaitOne(0))
                {
                    if (!shuttingDown) ServerTrace.Write("Stop signal received; open result windows=" + windows);
                    shuttingDown = true;
                    if (cookie != 0) { registrations.UnregisterTypeForComClients(cookie); cookie = 0; }
                    if (menuCookie != 0) { registrations.UnregisterTypeForComClients(menuCookie); menuCookie = 0; }
                    if (windows == 0) ExitThread();
                }
                else if (!resident && windows == 0 && (DateTime.UtcNow - lastUse).TotalSeconds > 120) ExitThread();
            };
            idle.Start();
            if (!embedding) dispatcher.BeginInvoke((Action)delegate
            {
                if (arguments.Length > 0) ShowBatch(arguments.ToList());
                else
                {
                    using (OpenFileDialog picker = new OpenFileDialog { Title = "Select image files to replace with verified PNGs", Filter = "All image files|*.*", Multiselect = true })
                    { if (picker.ShowDialog() == DialogResult.OK) ShowBatch(picker.FileNames.ToList()); else ExitThread(); }
                }
            });
        }
        private void ShowBatch(List<string> paths)
        {
            ServerTrace.Write("Batch received: " + paths.Count + " files.");
            lastUse = DateTime.UtcNow; ProgressWindow window = new ProgressWindow(paths); windows++;
            window.FormClosed += delegate { windows--; lastUse = DateTime.UtcNow; if (windows == 0 && (!resident || shuttingDown)) ExitThread(); };
            window.Show(); window.Activate();
        }
        protected override void ExitThreadCore()
        {
            ServerTrace.Write("Message loop exiting; result windows=" + windows);
            idle.Stop(); if (cookie != 0) { registrations.UnregisterTypeForComClients(cookie); cookie = 0; }
            if (menuCookie != 0) { registrations.UnregisterTypeForComClients(menuCookie); menuCookie = 0; }
            if (ready != null) { ready.Reset(); ready.Dispose(); shutdown.Dispose(); }
            dispatcher.Dispose(); base.ExitThreadCore();
        }
    }

    internal static class Installer
    {
        internal const string Verb = @"Software\Classes\*\shell\PNGConverterBatchV2";
        internal const string State = @"Software\PNGConverterBatchV2";
        internal const string AppPath = @"Software\Microsoft\Windows\CurrentVersion\App Paths\PNGConverterBatch.exe";
        internal const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
        internal const string RunName = "PNGConverterBatchV2";
        internal static readonly string Clsid = @"Software\Classes\CLSID\" + typeof(ShellDropTarget).GUID.ToString("B").ToUpperInvariant();
        internal static readonly string MenuClsid = @"Software\Classes\CLSID\" + typeof(ContextMenuTarget).GUID.ToString("B").ToUpperInvariant();
        internal static string BaseDirectory { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "PNGConverterBatchV2"); } }
        internal static string LogDirectory { get { return Path.Combine(BaseDirectory, "Logs"); } }
        internal static RegistryView[] Views { get { return Environment.Is64BitOperatingSystem ? new[] { RegistryView.Registry64, RegistryView.Registry32 } : new[] { RegistryView.Default }; } }
        private static string UserSuffix { get { return System.Security.Principal.WindowsIdentity.GetCurrent().User.Value; } }
        internal static string ReadyName { get { return @"Local\PNGConverterBatchV22.Ready." + UserSuffix; } }
        internal static string StopName { get { return @"Local\PNGConverterBatchV22.Stop." + UserSuffix; } }
        internal static string MutexName { get { return @"Local\PNGConverterBatchV22.Server." + UserSuffix; } }
        internal static string HostAppId { get { return typeof(ShellDropTarget).GUID.ToString("B").ToUpperInvariant(); } }
        internal static void SignalStop()
        { try { using (EventWaitHandle stop = EventWaitHandle.OpenExisting(StopName)) stop.Set(); } catch (WaitHandleCannotBeOpenedException) { } }
        internal static string StartupCommand(string exe) { return "\"" + exe + "\" --shell-server"; }
        internal static void CheckRunningHelper()
        {
            foreach (Guid id in new[] { typeof(ShellDropTarget).GUID, typeof(ContextMenuTarget).GUID })
            {
                Guid clsid = id, iid = typeof(IDropTarget).GUID; object instance;
                Native.Check(Native.CoCreateInstance(ref clsid, IntPtr.Zero, 4, ref iid, out instance));
                try { Native.Check(((IDropTarget)instance).DragLeave()); }
                finally { if (Marshal.IsComObject(instance)) Marshal.ReleaseComObject(instance); }
            }
        }
        internal static void EnsureHelper(string exe)
        {
            using (EventWaitHandle ready = new EventWaitHandle(false, EventResetMode.ManualReset, ReadyName))
            {
                if (ready.WaitOne(0)) { CheckRunningHelper(); return; }
                using (Process process = Process.Start(new ProcessStartInfo(exe, "--shell-server") { UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden, WorkingDirectory = Path.GetDirectoryName(exe) }))
                {
                    Stopwatch watch = Stopwatch.StartNew();
                    while (!ready.WaitOne(100))
                    {
                        if (process.HasExited) throw new IOException("The batch helper stopped during startup (exit " + process.ExitCode + ").");
                        if (watch.Elapsed.TotalSeconds > 60) throw new IOException("The batch helper has not reported ready after 60 seconds.");
                    }
                    CheckRunningHelper();
                }
            }
        }
        internal static void WriteRegistry(RegistryKey root, string exe, string shortcut)
        {
            foreach (string clsid in new[] { Clsid, MenuClsid })
            {
                string guid = clsid.Substring(clsid.LastIndexOf('\\') + 1);
                using (RegistryKey key = root.CreateSubKey(clsid)) { key.SetValue("", "PNG Converter Batch 2.2 native selection adapter"); key.DeleteValue("AppID", false); }
                root.DeleteSubKeyTree(clsid + @"\LocalServer32", false);
                string arch = root.View == RegistryView.Registry32 ? "x86" : Environment.Is64BitOperatingSystem ? "x64" : "x86";
                using (RegistryKey key = root.CreateSubKey(clsid + @"\InprocServer32")) { key.SetValue("", Path.Combine(Path.GetDirectoryName(exe), "PNGConverterDrop_" + arch + ".dll")); key.SetValue("ThreadingModel", "Apartment"); }
            }
            using (RegistryKey key = root.CreateSubKey(@"Software\Classes\AppID\PNGConverterBatch.exe")) key.SetValue("AppID", HostAppId);
            using (RegistryKey key = root.CreateSubKey(AppPath)) { key.SetValue("", exe); key.SetValue("DropTarget", typeof(ShellDropTarget).GUID.ToString("B")); }
            using (RegistryKey key = root.CreateSubKey(Verb))
            {
                key.SetValue("", "Convert to PNG (replace originals)"); key.SetValue("MUIVerb", "Convert to PNG (replace originals)");
                key.SetValue("MultiSelectModel", "Player"); key.SetValue("Icon", "\"" + exe + "\",0");
                key.SetValue("NeverDefault", "");
                using (RegistryKey drop = key.CreateSubKey("DropTarget")) drop.SetValue("CLSID", typeof(ContextMenuTarget).GUID.ToString("B"));
            }
            using (RegistryKey key = root.CreateSubKey(State)) { key.SetValue("InstallPath", exe); key.SetValue("ShortcutPath", shortcut); key.SetValue("Version", "2.2.0"); }
            using (RegistryKey key = root.CreateSubKey(RunKey))
                if (String.Equals(key.GetValue(RunName) as string, StartupCommand(exe), StringComparison.OrdinalIgnoreCase)) key.DeleteValue(RunName, false);
        }
        internal static string LinkTarget(string path)
        {
            object shell = Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell")); object link = null;
            try
            {
                link = shell.GetType().InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, shell, new object[] { path });
                return (string)link.GetType().InvokeMember("TargetPath", BindingFlags.GetProperty, null, link, null);
            }
            finally { if (link != null) Marshal.ReleaseComObject(link); Marshal.ReleaseComObject(shell); }
        }
        internal static void CreateLink(string path, string exe)
        {
            object shell = Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell")); object link = null;
            try
            {
                link = shell.GetType().InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, shell, new object[] { path });
                foreach (KeyValuePair<string, string> setting in new Dictionary<string, string> {
                    { "TargetPath", exe }, { "Arguments", "" }, { "WorkingDirectory", Path.GetDirectoryName(exe) },
                    { "Description", "Drop selected image files here. Originals are replaced only after PNG verification." }, { "IconLocation", "shell32.dll,142" } })
                    link.GetType().InvokeMember(setting.Key, BindingFlags.SetProperty, null, link, new object[] { setting.Value });
                link.GetType().InvokeMember("Save", BindingFlags.InvokeMethod, null, link, null);
            }
            finally { if (link != null) Marshal.ReleaseComObject(link); Marshal.ReleaseComObject(shell); }
            if (!String.Equals(LinkTarget(path), exe, StringComparison.OrdinalIgnoreCase)) throw new IOException("Desktop shortcut verification failed.");
        }
        internal static string Install(bool askForFolderAccess = true)
        {
            string previous = null, previousShortcut = null;
            using (RegistryKey old = Registry.CurrentUser.OpenSubKey(State)) if (old != null) { previous = old.GetValue("InstallPath") as string; previousShortcut = old.GetValue("ShortcutPath") as string; }
            string exe = MachineSetup.Executable;
            using (EventWaitHandle ready = new EventWaitHandle(false, EventResetMode.ManualReset, ReadyName))
            {
                SignalStop(); Stopwatch watch = Stopwatch.StartNew();
                while (ready.WaitOne(100)) { if (watch.Elapsed.TotalSeconds > 60) throw new IOException("Close the converter's result windows, then run INSTALL.cmd again."); Thread.Sleep(100); }
            }
            MachineSetup.Install();
            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            if (!Directory.Exists(desktop)) throw new DirectoryNotFoundException("Windows Desktop folder is unavailable.");
            bool ownedShortcut = previousShortcut != null && File.Exists(previousShortcut) && String.Equals(LinkTarget(previousShortcut), previous, StringComparison.OrdinalIgnoreCase);
            string shortcut = ownedShortcut ? previousShortcut : Path.Combine(desktop, "Convert to PNG (batch).lnk");
            if (!ownedShortcut && File.Exists(shortcut) && !String.Equals(LinkTarget(shortcut), exe, StringComparison.OrdinalIgnoreCase))
            {
                for (int n = 2; File.Exists(shortcut); n++) shortcut = Path.Combine(desktop, "Convert to PNG (batch " + n + ").lnk");
            }
            if (!File.Exists(shortcut) || (ownedShortcut && !String.Equals(LinkTarget(shortcut), exe, StringComparison.OrdinalIgnoreCase))) CreateLink(shortcut, exe);
            foreach (RegistryView view in Views) using (RegistryKey root = RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, view)) WriteRegistry(root, exe, shortcut);
            foreach (RegistryView view in Views) using (RegistryKey root = RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, view))
            {
                string legacy = @"Software\Classes\SystemFileAssociations\image\shell\PNGConverterBatchV2";
                using (RegistryKey drop = root.OpenSubKey(legacy + @"\DropTarget"))
                    if (drop != null && String.Equals(drop.GetValue("CLSID") as string, "{8B7F3D2A-12F4-4C65-91AB-725F3618D4E2}", StringComparison.OrdinalIgnoreCase)) root.DeleteSubKeyTree(legacy, false);
            }
            try { using (EventWaitHandle stop = EventWaitHandle.OpenExisting(@"Local\PNGConverterBatchV2.Stop." + UserSuffix)) stop.Set(); } catch (WaitHandleCannotBeOpenedException) { }
            try { using (EventWaitHandle stop = EventWaitHandle.OpenExisting(@"Local\PNGConverterBatchV21.Stop." + UserSuffix)) stop.Set(); } catch (WaitHandleCannotBeOpenedException) { }
            Native.SHChangeNotify(0x08000000, 0, IntPtr.Zero, IntPtr.Zero);
            return "PNG Converter 2.2 is ready. Installation, right-click setup and Windows folder permission are complete.\n\nDesktop shortcut: " + Path.GetFileNameWithoutExtension(shortcut) + "\n\nRight-click selected files > Show more options > Convert to PNG (replace originals).\n\nLogs: " + LogDirectory;
        }
        internal static string Uninstall()
        {
            string shortcut = null, installed = null;
            using (RegistryKey root = RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, Views[0])) using (RegistryKey state = root.OpenSubKey(State))
            { if (state != null) { installed = state.GetValue("InstallPath") as string; shortcut = state.GetValue("ShortcutPath") as string; } }
            if (installed == null) return "This converter is not registered for your account. No files were removed.";
            List<RegistryKey> roots = new List<RegistryKey>();
            try
            {
                foreach (RegistryView view in Views) roots.Add(RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, view));
                RemoveRegistrations(roots, installed);
            }
            finally { foreach (RegistryKey root in roots) root.Dispose(); }
            if (shortcut != null && File.Exists(shortcut) && String.Equals(LinkTarget(shortcut), installed, StringComparison.OrdinalIgnoreCase)) File.Delete(shortcut);
            try { using (EventWaitHandle stop = EventWaitHandle.OpenExisting(StopName)) stop.Set(); } catch (WaitHandleCannotBeOpenedException) { }
            Native.SHChangeNotify(0x08000000, 0, IntPtr.Zero, IntPtr.Zero);
            return "Converter menu, startup entry, and current desktop shortcut removed.\nThe helper stops when active conversion windows are finished and closed.\n\nConverted images, logs, saved application versions, and the previous converter were preserved.";
        }
        internal static void RemoveRegistrations(IList<RegistryKey> roots, string installed)
        {
            // App Paths, startup, and state are shared between Windows registry views.
            // Check every view before deleting anything; a first-view deletion is visible
            // in the second view, while CLSID registrations can be separate.
            foreach (RegistryKey root in roots)
                using (RegistryKey app = root.OpenSubKey(AppPath))
                    if (app == null || !String.Equals(app.GetValue("") as string, installed, StringComparison.OrdinalIgnoreCase))
                        throw new IOException("Registration has changed; no unrelated registration will be removed.");
            foreach (RegistryKey root in roots)
            {
                using (RegistryKey run = root.OpenSubKey(RunKey, true))
                    if (run != null && String.Equals(run.GetValue(RunName) as string, StartupCommand(installed), StringComparison.OrdinalIgnoreCase))
                        run.DeleteValue(RunName, false);
                root.DeleteSubKeyTree(Verb, false); root.DeleteSubKeyTree(AppPath, false); root.DeleteSubKeyTree(Clsid, false); root.DeleteSubKeyTree(MenuClsid, false); root.DeleteSubKeyTree(State, false);
                foreach (Guid id in new[] { typeof(ShellDropTarget).GUID, typeof(ContextMenuTarget).GUID }) root.DeleteSubKeyTree(@"Software\Classes\AppID\" + id.ToString("B").ToUpperInvariant(), false);
                using (RegistryKey map = root.OpenSubKey(@"Software\Classes\AppID\PNGConverterBatch.exe"))
                    if (map != null && String.Equals(map.GetValue("AppID") as string, HostAppId, StringComparison.OrdinalIgnoreCase)) root.DeleteSubKeyTree(@"Software\Classes\AppID\PNGConverterBatch.exe", false);
            }
        }
    }

    internal static class ServerTrace
    {
        internal static bool Enabled;
        internal static void Write(string message)
        {
            if (!Enabled) return;
            try
            {
                Directory.CreateDirectory(Installer.LogDirectory);
                File.AppendAllText(Path.Combine(Installer.LogDirectory, "SERVER_" + Process.GetCurrentProcess().Id + ".txt"), DateTime.Now.ToString("O") + " " + message + Environment.NewLine, Encoding.UTF8);
            }
            catch { }
        }
    }
    internal static class Program
    {
        [STAThread] internal static int Main(string[] args)
        {
            Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
            bool ole = false; Mutex serverMutex = null; bool ownsMutex = false;
            try
            {
                Native.Check(Native.OleInitialize(IntPtr.Zero)); ole = true;
                if (args.Length == 1 && args[0] == "--install") { MessageBox.Show(Installer.Install(), "PNG Converter - installed", MessageBoxButtons.OK, MessageBoxIcon.Information); return 0; }
                if (args.Length == 1 && args[0] == "--install-silent") { Installer.Install(false); return 0; }
                if (args.Length == 1 && args[0] == "--install-quiet") { Installer.Install(); return 0; }
                if (args.Length == 1 && args[0] == "--allow-folders") { MessageBox.Show(Protection.AllowInstalled(), "PNG Converter folder access"); return 0; }
                if (args.Length == 1 && args[0] == "--uninstall") { MessageBox.Show(Installer.Uninstall(), "PNG Converter - uninstall", MessageBoxButtons.OK, MessageBoxIcon.Information); return 0; }
                if (args.Length == 3 && args[0] == "--batch-list")
                {
                    BatchSummary summary = Converter.Run(File.ReadAllLines(args[1], Encoding.UTF8), args[2], message => { }, () => false);
                    return summary.Failed == 0 && summary.Error == null ? 0 : 1;
                }
                if (args.Length == 3 && args[0] == "--verify-folder") return ProtectedCheck.Run(args[1], args[2]);
                if (args.Length == 2 && args[0] == "--queued-batch") args = QueuedSelection.Read(args[1]);
                bool resident = args.Contains("--shell-server") || args.Any(a => a.Equals("/Embedding", StringComparison.OrdinalIgnoreCase) || a.Equals("-Embedding", StringComparison.OrdinalIgnoreCase));
                ServerTrace.Enabled = resident;
                ServerTrace.Write("Started: arguments=" + String.Join(" ", args) + "; identity=" + System.Security.Principal.WindowsIdentity.GetCurrent().Name);
                bool embedding = resident;
                if (embedding)
                {
                    serverMutex = new Mutex(true, Installer.MutexName, out ownsMutex);
                    if (!ownsMutex) { ServerTrace.Write("Another helper owns the server mutex; exiting."); serverMutex.Dispose(); serverMutex = null; return 0; }
                }
                ConverterContext context = new ConverterContext(embedding, resident, embedding ? new string[0] : args);
                ServerTrace.Write("Entering Windows message loop."); Application.Run(context);
                ServerTrace.Write("Windows message loop returned."); return 0;
            }
            catch (Exception error)
            {
                ServerTrace.Write("ERROR: " + error.ToString());
                if (args.Contains("--install-quiet") || args.Contains("--install-silent")) Console.Error.WriteLine(error.ToString());
                else MessageBox.Show(error.Message, "PNG Converter - error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }
            finally { if (ownsMutex && serverMutex != null) { serverMutex.ReleaseMutex(); serverMutex.Dispose(); } if (ole) Native.OleUninitialize(); }
        }
    }
}
