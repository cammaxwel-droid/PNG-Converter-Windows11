using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;

namespace PNGConverterBatch
{
    internal static class Protection
    {
        private const string Root = @"SOFTWARE\Microsoft\Windows Defender\Windows Defender Exploit Guard\Controlled Folder Access";
        internal static bool Enabled
        {
            get { try { using (RegistryKey key = Registry.LocalMachine.OpenSubKey(Root)) return key != null && Convert.ToInt32(key.GetValue("EnableControlledFolderAccess", 0)) == 1; } catch { return false; } }
        }
        internal static bool Allowed(string exe)
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(Root + @"\AllowedApplications"))
                    return key != null && key.GetValueNames().Any(n => String.Equals(Environment.ExpandEnvironmentVariables(n), exe, StringComparison.OrdinalIgnoreCase));
            }
            catch { return false; }
        }
        internal static string Explain(Exception error, string stage, string source)
        {
            int code = error.HResult & 0xFFFF;
            bool creation = stage == "Creating PNG in the source folder";
            if (creation && (code == 2 || code == 5) && Enabled && Directory.Exists(Native.LongPath(Path.GetDirectoryName(Path.GetFullPath(source)))))
                return "Windows refused to create the PNG in this existing folder. Controlled Folder Access is enabled. Click 'Allow folder access', approve the Windows prompt, then try this selection again. " + error.Message;
            return stage + ": " + error.Message;
        }
        internal static string PermissionScript(string exe)
        {
            string value = "'" + exe.Replace("'", "''") + "'";
            return "$ErrorActionPreference='Stop'; try { " +
                "$before=Get-MpPreference; Add-MpPreference -ControlledFolderAccessAllowedApplications " + value + "; " +
                "$after=Get-MpPreference; if ($after.EnableControlledFolderAccess -ne $before.EnableControlledFolderAccess) { throw 'Folder protection changed unexpectedly.' }; " +
                "if ($after.ControlledFolderAccessAllowedApplications -notcontains " + value + ") { throw 'Windows did not save the converter permission.' }; exit 0 " +
                "} catch { [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'PNG Converter permission failed') | Out-Null; exit 1 }";
        }
        internal static bool Allow(string installed, bool confirm)
        {
            string safe = Path.GetFullPath(installed);
            if ((!safe.StartsWith(Path.GetFullPath(Installer.BaseDirectory) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) && !String.Equals(safe, MachineSetup.Executable, StringComparison.OrdinalIgnoreCase)) || Path.GetFileName(safe) != "PNGConverterBatch.exe" || !File.Exists(safe))
                throw new IOException("Install the complete converter package before granting folder access.");
            if (confirm && MessageBox.Show("Windows folder protection blocked PNG creation.\n\nAllow only this PNG Converter to write into protected folders? Folder protection remains enabled, and existing permissions are preserved.\n\n" + safe + "\n\nWindows will ask for administrator approval.", "Allow PNG Converter folder access", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return false;
            string script = "Add-Type -AssemblyName System.Windows.Forms; " + PermissionScript(safe);
            string shell = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), @"WindowsPowerShell\v1.0\powershell.exe");
            using (Process child = Process.Start(new ProcessStartInfo(shell, "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + Convert.ToBase64String(Encoding.Unicode.GetBytes(script))) {
                UseShellExecute = true, Verb = "runas", WindowStyle = ProcessWindowStyle.Hidden
            })) { child.WaitForExit(); return child.ExitCode == 0; }
        }
        internal static string AllowInstalled()
        {
            string exe;
            using (RegistryKey state = Registry.CurrentUser.OpenSubKey(Installer.State)) exe = state == null ? null : state.GetValue("InstallPath") as string;
            if (exe == null) throw new IOException("Run INSTALL.cmd first.");
            if (!Allow(exe, true)) return "Folder permission was not changed. Originals are unchanged.";
            Installer.SignalStop();
            return "Folder access was saved for this converter. Windows folder protection is still enabled.\n\nClose any conversion windows, then double-click the desktop shortcut once to restart its helper before dropping files again.\nOriginal images were not changed by this permission step.";
        }
    }
}
