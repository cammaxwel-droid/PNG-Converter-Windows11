@echo off
setlocal
set "taskCompiler=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%taskCompiler%" set "taskCompiler=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%taskCompiler%" (
  echo The .NET Framework compiler was not found.
  pause
  exit /b 1
)
call "%~dp0BUILD_NATIVE.cmd"
if errorlevel 1 goto :failed
"%taskCompiler%" /nologo /codepage:65001 /target:winexe /platform:anycpu /optimize+ /reference:System.Drawing.dll /reference:System.Windows.Forms.dll /out:"%~dp0..\PNGConverterBatch.exe" /win32manifest:"%~dp0app.manifest" "%~dp0PNGConverterBatch.cs" "%~dp0ImageEngine.cs" "%~dp0Protection.cs" "%~dp0ProtectedCheck.cs" "%~dp0MachineSetup.cs" "%~dp0QueuedSelection.cs"
if errorlevel 1 goto :failed
copy /y "%~dp0PNGConverterBatch.exe.config" "%~dp0..\PNGConverterBatch.exe.config" >nul
if errorlevel 1 goto :failed
echo Build succeeded.
exit /b 0
:failed
echo Build failed. See the error above.
pause
exit /b 1
