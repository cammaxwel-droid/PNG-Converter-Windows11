@echo off
setlocal
set "taskVswhere=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%taskVswhere%" goto :missing
for /f "usebackq delims=" %%i in (`"%taskVswhere%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "taskVisualStudio=%%i"
if not defined taskVisualStudio goto :missing
call "%taskVisualStudio%\VC\Auxiliary\Build\vcvarsall.bat" x64 >nul
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /MT /LD /O2 /W4 /DUNICODE /D_UNICODE "%~dp0NativeDrop.cpp" /Fo"%~dp0..\NativeDrop_x64.obj" /Fe"%~dp0..\PNGConverterDrop_x64.dll" /link /DEF:"%~dp0NativeDrop.def" shell32.lib ole32.lib user32.lib uuid.lib
if errorlevel 1 exit /b 1
call "%taskVisualStudio%\VC\Auxiliary\Build\vcvarsall.bat" x86 >nul
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /MT /LD /O2 /W4 /DUNICODE /D_UNICODE "%~dp0NativeDrop.cpp" /Fo"%~dp0..\NativeDrop_x86.obj" /Fe"%~dp0..\PNGConverterDrop_x86.dll" /link /DEF:"%~dp0NativeDrop.def" shell32.lib ole32.lib user32.lib uuid.lib
exit /b %errorlevel%
:missing
echo Rebuilding the native adapters requires Visual Studio C++ Build Tools and the Windows SDK.
echo Normal installation uses the supplied adapters: run INSTALL.cmd in the package folder.
exit /b 1
