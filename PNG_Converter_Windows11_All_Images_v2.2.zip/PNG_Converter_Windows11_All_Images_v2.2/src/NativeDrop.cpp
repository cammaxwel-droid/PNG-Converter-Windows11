#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shlobj.h>
#include <shellapi.h>
#include <string>
#include <vector>
#include <new>

// Explorer loads only this native selection adapter. Image decoding and deletion
// take place in the separate converter process, after the selection is copied.
static HMODULE module;
static LONG objects = 0, locks = 0;
static const CLSID DragClass = {0xb933fb76,0x015d,0x4a3b,{0x8b,0xa8,0xe4,0x85,0x55,0x84,0x46,0x0a}};
static const CLSID MenuClass = {0x936be8b2,0x82f3,0x4d3e,{0xa8,0x14,0x15,0x47,0x54,0xa5,0xb3,0x9d}};
static FORMATETC DropFormat() { FORMATETC f = {CF_HDROP, nullptr, DVASPECT_CONTENT, -1, TYMED_HGLOBAL}; return f; }
static bool HasFiles(IDataObject* data) { FORMATETC f = DropFormat(); return data && SUCCEEDED(data->QueryGetData(&f)); }

static HRESULT Queue(IDataObject* data) {
    FORMATETC format = DropFormat(); STGMEDIUM medium = {};
    HRESULT hr = data ? data->GetData(&format, &medium) : E_INVALIDARG;
    if (FAILED(hr)) return hr;
    std::wstring selection = L"PNGConverterBatchSelectionV22\r\n";
    try {
        UINT count = DragQueryFileW((HDROP)medium.hGlobal, 0xffffffff, nullptr, 0);
        if (!count) { ReleaseStgMedium(&medium); return E_INVALIDARG; }
        for (UINT i = 0; i < count; ++i) {
            UINT size = DragQueryFileW((HDROP)medium.hGlobal, i, nullptr, 0);
            std::vector<wchar_t> name((size_t)size + 1);
            if (!size || DragQueryFileW((HDROP)medium.hGlobal, i, name.data(), size + 1) != size) {
                ReleaseStgMedium(&medium); return E_UNEXPECTED;
            }
            selection.append(name.data(), size); selection += L"\r\n";
        }
    } catch (...) { ReleaseStgMedium(&medium); return E_OUTOFMEMORY; }
    ReleaseStgMedium(&medium);

    PWSTR local = nullptr;
    hr = SHGetKnownFolderPath(FOLDERID_LocalAppData, 0, nullptr, &local);
    if (FAILED(hr)) return hr;
    std::wstring base = std::wstring(local) + L"\\PNGConverterBatchV2";
    CoTaskMemFree(local);
    if (!CreateDirectoryW(base.c_str(), nullptr) && GetLastError() != ERROR_ALREADY_EXISTS) return HRESULT_FROM_WIN32(GetLastError());
    std::wstring queue = base + L"\\Queue";
    if (!CreateDirectoryW(queue.c_str(), nullptr) && GetLastError() != ERROR_ALREADY_EXISTS) return HRESULT_FROM_WIN32(GetLastError());
    GUID id; hr = CoCreateGuid(&id); if (FAILED(hr)) return hr;
    wchar_t text[40]; if (!StringFromGUID2(id, text, 40)) return E_UNEXPECTED;
    std::wstring name = L"batch-";
    for (wchar_t ch : std::wstring(text)) if (ch != L'{' && ch != L'}' && ch != L'-') name += ch;
    name += L".txt";
    std::wstring file = queue + L"\\" + name;
    HANDLE handle = CreateFileW(file.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (handle == INVALID_HANDLE_VALUE) return HRESULT_FROM_WIN32(GetLastError());
    DWORD written = 0; WORD bom = 0xfeff;
    bool ok = WriteFile(handle, &bom, sizeof(bom), &written, nullptr) && written == sizeof(bom);
    size_t bytes = selection.size() * sizeof(wchar_t);
    if (bytes > MAXDWORD) ok = false;
    if (ok) ok = WriteFile(handle, selection.data(), (DWORD)bytes, &written, nullptr) && written == bytes;
    if (ok) ok = FlushFileBuffers(handle) != FALSE;
    DWORD error = ok ? 0 : GetLastError(); CloseHandle(handle);
    if (!ok) { DeleteFileW(file.c_str()); return HRESULT_FROM_WIN32(error ? error : ERROR_WRITE_FAULT); }

    wchar_t path[32768]; DWORD length = GetModuleFileNameW(module, path, 32768);
    if (!length || length >= 32768) { DeleteFileW(file.c_str()); return E_UNEXPECTED; }
    std::wstring folder(path, length); size_t split = folder.find_last_of(L"\\/");
    if (split == std::wstring::npos) { DeleteFileW(file.c_str()); return E_UNEXPECTED; }
    folder.resize(split);
    std::wstring exe = folder + L"\\PNGConverterBatch.exe";
    // The command contains a short request filename, never selected image paths.
    std::wstring command = L"\"" + exe + L"\" --queued-batch \"" + name + L"\"";
    std::vector<wchar_t> mutableCommand(command.begin(), command.end()); mutableCommand.push_back(0);
    STARTUPINFOW startup = {}; startup.cb = sizeof(startup);
    PROCESS_INFORMATION process = {};
    ok = CreateProcessW(exe.c_str(), mutableCommand.data(), nullptr, nullptr, FALSE, 0, nullptr, folder.c_str(), &startup, &process) != FALSE;
    error = GetLastError();
    if (!ok) { DeleteFileW(file.c_str()); return HRESULT_FROM_WIN32(error); }
    CloseHandle(process.hThread); CloseHandle(process.hProcess);
    return S_OK;
}

class Target final : public IDropTarget {
    LONG refs = 1; bool menu, accepts = false;
public:
    explicit Target(bool command) : menu(command) { InterlockedIncrement(&objects); }
    ~Target() { InterlockedDecrement(&objects); }
    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID iid, void** value) override {
        if (!value) return E_POINTER; *value = nullptr;
        if (iid != IID_IUnknown && iid != IID_IDropTarget) return E_NOINTERFACE;
        *value = static_cast<IDropTarget*>(this); AddRef(); return S_OK;
    }
    ULONG STDMETHODCALLTYPE AddRef() override { return (ULONG)InterlockedIncrement(&refs); }
    ULONG STDMETHODCALLTYPE Release() override { LONG count = InterlockedDecrement(&refs); if (!count) delete this; return (ULONG)count; }
    HRESULT STDMETHODCALLTYPE DragEnter(IDataObject* data, DWORD, POINTL, DWORD* effect) override {
        if (!effect) return E_POINTER; accepts = HasFiles(data);
        *effect = accepts ? (*effect & DROPEFFECT_COPY) : DROPEFFECT_NONE; return S_OK;
    }
    HRESULT STDMETHODCALLTYPE DragOver(DWORD, POINTL, DWORD* effect) override {
        if (!effect) return E_POINTER; *effect = accepts ? (*effect & DROPEFFECT_COPY) : DROPEFFECT_NONE; return S_OK;
    }
    HRESULT STDMETHODCALLTYPE DragLeave() override { accepts = false; return S_OK; }
    HRESULT STDMETHODCALLTYPE Drop(IDataObject* data, DWORD, POINTL, DWORD* effect) override {
        if (!effect) return E_POINTER;
        bool requested = menu || ((*effect & DROPEFFECT_COPY) != 0); *effect = DROPEFFECT_NONE;
        if (!requested) return S_OK;
        HRESULT hr;
        try { hr = Queue(data); } catch (...) { hr = E_OUTOFMEMORY; }
        if (FAILED(hr)) {
            wchar_t error[160]; wsprintfW(error, L"Windows could not start the conversion (error 0x%08X).\nNo image files were changed. Run INSTALL.cmd again to repair the converter.", (UINT)hr);
            MessageBoxW(nullptr, error, L"PNG Converter - conversion did not start", MB_OK | MB_ICONERROR);
        }
        if (SUCCEEDED(hr) && !menu) *effect = DROPEFFECT_COPY;
        // Never MOVE: only the converter may delete a verified source.
        return hr;
    }
};
class Factory final : public IClassFactory {
    LONG refs = 1; bool menu;
public:
    explicit Factory(bool command) : menu(command) { InterlockedIncrement(&objects); }
    ~Factory() { InterlockedDecrement(&objects); }
    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID iid, void** value) override {
        if (!value) return E_POINTER; *value = nullptr;
        if (iid != IID_IUnknown && iid != IID_IClassFactory) return E_NOINTERFACE;
        *value = static_cast<IClassFactory*>(this); AddRef(); return S_OK;
    }
    ULONG STDMETHODCALLTYPE AddRef() override { return (ULONG)InterlockedIncrement(&refs); }
    ULONG STDMETHODCALLTYPE Release() override { LONG count = InterlockedDecrement(&refs); if (!count) delete this; return (ULONG)count; }
    HRESULT STDMETHODCALLTYPE CreateInstance(IUnknown* outer, REFIID iid, void** value) override {
        if (!value) return E_POINTER; *value = nullptr; if (outer) return CLASS_E_NOAGGREGATION;
        Target* target = new (std::nothrow) Target(menu); if (!target) return E_OUTOFMEMORY;
        HRESULT hr = target->QueryInterface(iid, value); target->Release(); return hr;
    }
    HRESULT STDMETHODCALLTYPE LockServer(BOOL locked) override { if (locked) InterlockedIncrement(&locks); else InterlockedDecrement(&locks); return S_OK; }
};
extern "C" HRESULT __stdcall DllGetClassObject(REFCLSID clsid, REFIID iid, void** value) {
    if (!value) return E_POINTER; *value = nullptr;
    if (clsid != DragClass && clsid != MenuClass) return CLASS_E_CLASSNOTAVAILABLE;
    Factory* factory = new (std::nothrow) Factory(clsid == MenuClass);
    if (!factory) return E_OUTOFMEMORY;
    HRESULT hr = factory->QueryInterface(iid, value); factory->Release(); return hr;
}
extern "C" HRESULT __stdcall DllCanUnloadNow() { return objects == 0 && locks == 0 ? S_OK : S_FALSE; }
BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID) { if (reason == DLL_PROCESS_ATTACH) { module = instance; DisableThreadLibraryCalls(instance); } return TRUE; }
