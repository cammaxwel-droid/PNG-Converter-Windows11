using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
namespace PNGConverterBatch
{
    internal static class MachineSetup
    {
        internal static string DirectoryPath { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "PNGConverterBatch"); } }
        internal static string Executable { get { return Path.Combine(DirectoryPath, "PNGConverterBatch.exe"); } }
        internal static readonly string[] EngineFiles = { "magick.exe", "LICENSE.txt", "NOTICE.txt", "sRGB.icc", "colors.xml", "configure.xml", "delegates.xml", "english.xml", "locale.xml", "log.xml", "mime.xml", "policy.xml", "thresholds.xml", "type-ghostscript.xml", "type.xml" };
        private static string Literal(string value) { return "'" + value.Replace("'", "''") + "'"; }
        private static string Hash(string path) { using (FileStream file = File.OpenRead(path)) using (SHA256 hash = SHA256.Create()) return BitConverter.ToString(hash.ComputeHash(file)).Replace("-", ""); }
        internal static string Script(string errorReport = null)
        {
            string source = Assembly.GetExecutingAssembly().Location;
            StringBuilder script = new StringBuilder("$ErrorActionPreference='Stop'; try { ");
            script.Append("$target=").Append(Literal(DirectoryPath)).Append("; $before=Get-MpPreference; ");
            script.Append("foreach($dir in @($target,(Join-Path $target 'engine'))) { if(Test-Path -LiteralPath $dir) { if((Get-Item -LiteralPath $dir).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'A linked installation folder cannot be used.' } } else { New-Item -ItemType Directory -Path $dir | Out-Null } }; ");
            script.Append("$existing=Join-Path $target 'PNGConverterBatch.exe'; if(Test-Path -LiteralPath $existing) { if([Reflection.AssemblyName]::GetAssemblyName($existing).Name -ne 'PNGConverterBatch') { throw 'An unrelated application occupies the installation path.' } }; ");
            foreach (string relative in new[] { "PNGConverterBatch.exe", "PNGConverterBatch.exe.config", "PNGConverterDrop_x64.dll", "PNGConverterDrop_x86.dll" }.Concat(EngineFiles.Select(file => "engine\\" + file)))
            {
                string from = relative.StartsWith("engine\\", StringComparison.Ordinal) ? Path.Combine(ImageEngine.DirectoryPath, relative.Substring(7)) : relative.EndsWith(".config", StringComparison.Ordinal) ? source + ".config" : relative.EndsWith(".dll", StringComparison.Ordinal) ? Path.Combine(Path.GetDirectoryName(source), relative) : source;
                string to = Path.Combine(DirectoryPath, relative), expected = Hash(from);
                script.Append("$from=").Append(Literal(from)).Append("; $to=").Append(Literal(to)).Append("; $hash=").Append(Literal(expected)).Append("; ");
                script.Append("if((Get-FileHash -LiteralPath $from -Algorithm SHA256).Hash -ne $hash) { throw 'Source package changed during setup.' }; ");
                script.Append("if(-not (Test-Path -LiteralPath $to) -or (Get-FileHash -LiteralPath $to -Algorithm SHA256).Hash -ne $hash) { Copy-Item -LiteralPath $from -Destination $to -Force }; if((Get-FileHash -LiteralPath $to -Algorithm SHA256).Hash -ne $hash) { throw 'Installed file checksum differs.' }; ");
            }
            script.Append("$exe=").Append(Literal(Executable)).Append("; ");
            foreach (Guid id in new[] { typeof(ShellDropTarget).GUID, typeof(ContextMenuTarget).GUID })
            {
                string guid = id.ToString("B").ToUpperInvariant();
                foreach (string view in new[] { "Registry64", "Registry32" })
                {
                    script.Append("$root=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine,[Microsoft.Win32.RegistryView]::").Append(view).Append("); ");
                    string classKey = @"SOFTWARE\Classes\CLSID\" + guid;
                    script.Append("$key=$root.CreateSubKey(").Append(Literal(classKey)).Append("); $key.SetValue('','PNG Converter Batch 2.2 native selection adapter'); $key.DeleteValue('AppID',$false); $key.Dispose(); ");
                    script.Append("$root.DeleteSubKeyTree(").Append(Literal(classKey + @"\LocalServer32")).Append(",$false); ");
                    script.Append("$key=$root.CreateSubKey(").Append(Literal(classKey + @"\InprocServer32")).Append("); $key.SetValue('',").Append(Literal(Path.Combine(DirectoryPath, view == "Registry64" ? "PNGConverterDrop_x64.dll" : "PNGConverterDrop_x86.dll"))).Append("); $key.SetValue('ThreadingModel','Apartment'); $key.Dispose(); $root.Dispose(); ");
                }
            }
            script.Append("if($before.EnableControlledFolderAccess -eq 1) { Add-MpPreference -ControlledFolderAccessAllowedApplications $exe }; $after=Get-MpPreference; ");
            script.Append("if($after.EnableControlledFolderAccess -ne $before.EnableControlledFolderAccess) { throw 'Folder protection changed unexpectedly.' }; if($before.EnableControlledFolderAccess -eq 1 -and $after.ControlledFolderAccessAllowedApplications -notcontains $exe) { throw 'Windows did not save the converter permission.' }; exit 0 ");
            script.Append("} catch { ");
            if (errorReport != null) script.Append("[IO.File]::WriteAllText(").Append(Literal(errorReport)).Append(", $_.Exception.ToString()); ");
            script.Append("exit 1 }");
            return script.ToString();
        }
        internal static string Bootstrap(string code, string errorReport)
        {
            string packedCode;
            using (MemoryStream packed = new MemoryStream())
            {
                byte[] bytes = Encoding.UTF8.GetBytes(code);
                using (GZipStream gzip = new GZipStream(packed, CompressionMode.Compress, true)) gzip.Write(bytes, 0, bytes.Length);
                packedCode = Convert.ToBase64String(packed.ToArray());
            }
            return "$ErrorActionPreference='Stop'; try { $bytes=[Convert]::FromBase64String('" + packedCode + "'); $stream=[IO.MemoryStream]::new($bytes); $gzip=[IO.Compression.GZipStream]::new($stream,[IO.Compression.CompressionMode]::Decompress); $reader=[IO.StreamReader]::new($gzip,[Text.Encoding]::UTF8); $code=$reader.ReadToEnd(); $reader.Dispose(); Invoke-Expression $code } catch { [IO.File]::WriteAllText(" + Literal(errorReport) + ", $_.Exception.ToString()); exit 1 }";
        }
        internal static void Install()
        {
            Directory.CreateDirectory(Installer.LogDirectory);
            string errorReport = Path.Combine(Installer.LogDirectory, "INSTALL_" + DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss") + "_" + Guid.NewGuid().ToString("N").Substring(0, 8) + ".txt");
            string script = Bootstrap(Script(errorReport), errorReport);
            string encoded = Convert.ToBase64String(Encoding.Unicode.GetBytes(script));
            if (encoded.Length > 30000) throw new IOException("The installation command exceeded its supported Windows length.");
            string shell = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), @"WindowsPowerShell\v1.0\powershell.exe");
            using (Process process = Process.Start(new ProcessStartInfo(shell, "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + encoded) { UseShellExecute = true, Verb = "runas", WindowStyle = ProcessWindowStyle.Hidden }))
            {
                process.WaitForExit();
                if (process.ExitCode != 0) throw new IOException(File.Exists(errorReport) ? "Installation failed: " + File.ReadAllText(errorReport) + "\n\nLog: " + errorReport : "Windows installation was not completed. Run INSTALL.cmd and approve the Windows administrator prompt.");
            }
            if (Hash(Executable) != Hash(Assembly.GetExecutingAssembly().Location)) throw new IOException("The installed converter checksum differs.");
        }
    }
}
