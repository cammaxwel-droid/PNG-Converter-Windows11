using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace PNGConverterBatch
{
    internal sealed class PreparedImage : IDisposable
    {
        internal Bitmap Raster;
        internal byte[] Profile;
        internal string EncodedPng, EncodedHash, Scratch, KeepReason;
        internal int Width, Height;
        internal string PixelHash;
        public void Dispose()
        {
            if (Raster != null) Raster.Dispose();
            // Remove only this process's unique scratch directory, never source/output folders.
            if (Scratch != null)
            {
                string safe = Path.GetFullPath(Scratch), parent = Path.GetFullPath(ImageEngine.ScratchRoot) + Path.DirectorySeparatorChar;
                if (safe.StartsWith(parent, StringComparison.OrdinalIgnoreCase))
                    try { Directory.Delete(safe, true); } catch { }
            }
        }
    }
    internal static class ImageEngine
    {
        internal static string ScratchOverride;
        internal static string DirectoryPath
        {
            get
            {
                string folder = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                if (!System.IO.Directory.Exists(Path.Combine(folder, "engine"))) folder = Path.GetDirectoryName(folder);
                return Path.Combine(folder, "engine");
            }
        }
        internal static string Executable { get { return Path.Combine(DirectoryPath, "magick.exe"); } }
        internal static string ScratchRoot { get { return ScratchOverride ?? Path.Combine(Installer.BaseDirectory, "Scratch"); } }
        internal static string Quote(string value)
        {
            StringBuilder result = new StringBuilder("\""); int slashes = 0;
            foreach (char c in value)
            {
                if (c == '\\') { slashes++; continue; }
                if (c == '"') { result.Append('\\', slashes * 2 + 1); result.Append(c); }
                else { result.Append('\\', slashes); result.Append(c); }
                slashes = 0;
            }
            result.Append('\\', slashes * 2); return result.Append('"').ToString();
        }
        internal static string Run(params string[] arguments) { return Execute(false, arguments); }
        private static string Execute(bool pixels, params string[] arguments)
        {
            if (!File.Exists(Executable)) throw new IOException("The bundled image decoder is missing. Extract the complete package and install again.");
            ProcessStartInfo start = new ProcessStartInfo(Executable, String.Join(" ", arguments.Select(Quote))) {
                UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true,
                RedirectStandardError = true, WindowStyle = ProcessWindowStyle.Hidden, WorkingDirectory = DirectoryPath
            };
            start.EnvironmentVariables["MAGICK_CONFIGURE_PATH"] = DirectoryPath;
            start.EnvironmentVariables["MAGICK_TEMPORARY_PATH"] = ScratchRoot;
            using (Process process = Process.Start(start))
            {
                Task<string> errors = process.StandardError.ReadToEndAsync(); string result;
                if (pixels)
                {
                    using (SHA256 hash = SHA256.Create()) result = BitConverter.ToString(hash.ComputeHash(process.StandardOutput.BaseStream)).Replace("-", "");
                }
                else result = process.StandardOutput.ReadToEnd();
                process.WaitForExit(); string error = errors.GetAwaiter().GetResult();
                if (process.ExitCode != 0 || !String.IsNullOrWhiteSpace(error))
                    throw new InvalidDataException("Image decoder could not safely read/convert this file: " + (String.IsNullOrWhiteSpace(error) ? "exit " + process.ExitCode : error.Trim()));
                return result;
            }
        }
        internal static string PixelHash(string path)
        {
            string dimensions = Run(path, "-auto-orient", "-format", "%w|%h", "info:-");
            string pixels = Execute(true, path, "-auto-orient", "-colorspace", "sRGB", "-depth", "16", "RGBA:-");
            using (SHA256 sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(Encoding.ASCII.GetBytes(dimensions + ":" + pixels))).Replace("-", "");
        }
        internal static PreparedImage Prepare(Stream original, string source)
        {
            PreparedImage result = new PreparedImage();
            try
            {
                Directory.CreateDirectory(Native.LongPath(ScratchRoot));
                result.Scratch = Path.Combine(ScratchRoot, Guid.NewGuid().ToString("N")); Directory.CreateDirectory(Native.LongPath(result.Scratch));
                // Give the decoder only our byte-identical snapshot, with a short safe filename.
                string extension = Path.GetExtension(source);
                if (extension.Length > 15 || extension.Any(c => !Char.IsLetterOrDigit(c) && c != '.')) extension = ".image";
                string snapshot = Path.Combine(result.Scratch, "source" + extension);
                original.Position = 0;
                using (FileStream copy = new FileStream(snapshot, FileMode.CreateNew, FileAccess.Write, FileShare.None)) { original.CopyTo(copy); copy.Flush(true); }
                string decoderInput = snapshot;
                if (extension.Equals(".svg", StringComparison.OrdinalIgnoreCase) || extension.Equals(".svgz", StringComparison.OrdinalIgnoreCase)) decoderInput = "RSVG:" + snapshot;
                string[] info = Run("identify", "-format", "%m|%w|%h|%n|%z\n", decoderInput).Trim().Split('\n');
                if (info.Length == 0) throw new InvalidDataException("No image was found in this file.");
                string[] first = info[0].Trim().Split('|'); int count, depth;
                if (first.Length != 5 || !Int32.TryParse(first[3], out count) || !Int32.TryParse(first[4], out depth)) throw new InvalidDataException("Image information was incomplete.");
                if (depth > 16) throw new InvalidDataException("This image has more precision than PNG can preserve. Original kept.");
                string input = decoderInput;
                if (count > 1 || info.Length > 1)
                {
                    input += "[0]";
                    result.KeepReason = "PNG preview created. The original contains multiple frames/pages/layers and was kept to preserve them.";
                }
                // PNG is a lossless rendering of the selected image, not a filename-only change.
                result.EncodedPng = Path.Combine(result.Scratch, "decoded.png");
                Run(input, "-auto-orient", "-colorspace", "sRGB", "PNG:" + result.EncodedPng);
                result.PixelHash = PixelHash(input);
                if (PixelHash(result.EncodedPng) != result.PixelHash) throw new InvalidDataException("Converted PNG differs from the source's full 16-bit rendered pixels. Original kept.");
                using (FileStream png = File.OpenRead(result.EncodedPng)) { Converter.CheckPng(png); result.EncodedHash = Converter.Hash(png); }
                using (Bitmap image = new Bitmap(result.EncodedPng)) { result.Width = image.Width; result.Height = image.Height; }
                return result;
            }
            catch { result.Dispose(); throw; }
        }
        internal static void Save(PreparedImage prepared, FileStream output)
        {
            if (prepared.EncodedPng != null) using (FileStream png = File.OpenRead(prepared.EncodedPng)) png.CopyTo(output);
            else Converter.SavePng(prepared.Raster, output, prepared.Profile);
        }
        internal static void Verify(PreparedImage prepared, FileStream stream, string path)
        {
            if (prepared.EncodedPng == null) Converter.VerifyPng(stream, prepared.Width, prepared.Height, prepared.PixelHash, prepared.Profile);
            else
            {
                Converter.CheckPng(stream);
                using (Bitmap image = (Bitmap)Image.FromStream(stream, false, true))
                    if (image.Width != prepared.Width || image.Height != prepared.Height) throw new InvalidDataException("PNG dimensions differ. Original kept.");
                if (Converter.Hash(stream) != prepared.EncodedHash) throw new InvalidDataException("PNG bytes changed after encoding. Original kept.");
            }
        }
    }
}
