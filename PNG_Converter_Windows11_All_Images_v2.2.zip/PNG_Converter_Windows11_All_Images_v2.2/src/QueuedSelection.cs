using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace PNGConverterBatch
{
    internal static class QueuedSelection
    {
        internal static string DirectoryPath { get { return Path.Combine(Installer.BaseDirectory, "Queue"); } }
        internal static string[] Read(string name)
        {
            if (name == null || !name.StartsWith("batch-", StringComparison.Ordinal) || !name.EndsWith(".txt", StringComparison.Ordinal) || name.Length != 42)
                throw new InvalidDataException("Windows supplied an invalid selection request. No images were changed.");
            Guid id; if (!Guid.TryParseExact(name.Substring(6, 32), "N", out id)) throw new InvalidDataException("Invalid selection request identifier.");
            string file = Path.Combine(DirectoryPath, name);
            using (SourceLease lease = new SourceLease(file))
            {
                if (lease.Stream.Length > 67108864) throw new InvalidDataException("The selection request is too large. No images were changed.");
                using (StreamReader reader = new StreamReader(lease.Stream, Encoding.Unicode, true, 4096, true))
                {
                    if (reader.ReadLine() != "PNGConverterBatchSelectionV22") throw new InvalidDataException("Invalid Windows selection request header.");
                    List<string> paths = new List<string>(); string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line.Length == 0 || !Path.IsPathRooted(line)) throw new InvalidDataException("An incomplete image path was received. No images were changed.");
                        paths.Add(line);
                    }
                    if (paths.Count == 0) throw new InvalidDataException("No image files were received.");
                    // Remove only this consumed request; image files have not been opened yet.
                    if (lease.CanDelete) lease.DeleteOriginal();
                    return paths.ToArray();
                }
            }
        }
    }
}
