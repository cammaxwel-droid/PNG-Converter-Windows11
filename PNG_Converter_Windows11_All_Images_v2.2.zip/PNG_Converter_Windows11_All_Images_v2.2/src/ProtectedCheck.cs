using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;

namespace PNGConverterBatch
{
    internal static class ProtectedCheck
    {
        internal static int Run(string existingFolder, string report)
        {
            string folder = null;
            try
            {
                if (!Directory.Exists(existingFolder)) throw new DirectoryNotFoundException("Verification target folder is unavailable.");
                folder = Path.Combine(existingFolder, "_PNGConverter_Check_" + Guid.NewGuid().ToString("N"));
                Directory.CreateDirectory(folder); List<string> files = new List<string>(); Dictionary<string, string> pixels = new Dictionary<string, string>();
                using (Bitmap pattern = new Bitmap(31, 19))
                {
                    for (int y = 0; y < pattern.Height; y++) for (int x = 0; x < pattern.Width; x++) pattern.SetPixel(x, y, Color.FromArgb((x * 47 + y * 11) & 255, (x * 13 + y * 43) & 255, (x * 5 + y * 37) & 255));
                    foreach (ImageFormat format in new[] { ImageFormat.Jpeg, ImageFormat.Bmp, ImageFormat.Gif, ImageFormat.Tiff })
                    {
                        string path = Path.Combine(folder, "sample." + format.ToString().ToLowerInvariant()); pattern.Save(path, format); files.Add(path);
                        using (Bitmap image = new Bitmap(path)) pixels[path] = Converter.Pixels(image);
                    }
                }
                Directory.CreateDirectory(ImageEngine.ScratchRoot);
                string scratch = Path.Combine(ImageEngine.ScratchRoot, "check-" + Guid.NewGuid().ToString("N") + ".webp");
                try { ImageEngine.Run(files[0], scratch); string webp = Path.Combine(folder, "sample.webp"); File.Copy(scratch, webp, false); files.Add(webp); }
                finally { if (File.Exists(scratch)) File.Delete(scratch); }
                BatchSummary summary = Converter.Run(files, Path.Combine(folder, "logs"), notice => { }, () => false);
                if (summary.Replaced != files.Count || summary.Failed != 0 || summary.Error != null) throw new IOException(summary.Text + " " + summary.Error + " Inspect " + summary.LogPath);
                if (Directory.GetFiles(folder, "*.png").Length != files.Count) throw new IOException("Protected-folder output count differs.");
                foreach (Result result in summary.Results)
                {
                    if (File.Exists(result.Source)) throw new IOException("Disposable original was not replaced.");
                    using (FileStream png = File.OpenRead(result.Output)) Converter.CheckPng(png);
                    if (pixels.ContainsKey(result.Source)) using (Bitmap image = new Bitmap(result.Output))
                        if (Converter.Pixels(image) != pixels[result.Source]) throw new IOException("Protected-folder decoded pixels differ.");
                }
                File.WriteAllText(report, "PASS: actual production process created and verified 5 PNGs inside the target folder.\r\nOnly generated disposable source images were deleted after verification.\r\nNo pre-existing image files were opened for conversion or changed.\r\n" + summary.Text + "\r\nTest folder: " + folder + "\r\nLog: " + summary.LogPath, new UTF8Encoding(true));
                return 0;
            }
            catch (Exception error)
            {
                File.WriteAllText(report, "FAIL: " + error + "\r\nTest folder: " + folder, new UTF8Encoding(true)); return 1;
            }
        }
    }
}
